<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$shortcodes_info = Tapgoods_Shortcodes::get_shortcodes();

?>
<div class="container">


    <h2 class="mb-4">Shortcodes</h2>

    <!-- Row 1 -->
	<div class="row mb-3">
	<!-- Column for the title -->
	<div class="col-md-2">
		<h3 class="fw-bold active" style="color: var(--tg-blue);">Show Inventory</h3>

	</div>
	
	<!-- Column for the content and preview -->
	<div class="col-md-10">
		<div class="row">
			<!-- Content -->
			<div class="col-md-8">
				<form>
					<div class="input-group mb-3">
						<span id="tapgoods-inventory-input" class="form-control tapgoods-shortcode-display" role="textbox" aria-readonly="true" aria-label="Show Inventory shortcode" tabindex="0" data-shortcode="[tapgoods-inventory]">[tapgoods-inventory]</span>
						<button type="button" onClick="copyText('tapgoods-inventory-input')"
								data-bs-toggle="tooltip" data-bs-placement="bottom"
								data-bs-title="Copy to clipboard"
								aria-label="Copy Show Inventory shortcode to clipboard"
								class="btn btn-outline-secondary">
							<span class="dashicons dashicons-admin-page"></span>
						</button>
					</div>
				</form>
				<p class="text-muted">
					Use this shortcode to add inventory to any page. Example pages could be a SHOP PAGE, 
					or a page you want to show off specifically tagged inventory.
				</p>
				<p style="color: var(--tg-blue);"><strong>Shortcode Modifiers:</strong></p>
				<ul class="text-muted">
					<li><strong>Filter by Categories:</strong> <code>[tapgoods-inventory category="your-category, your-category"]</code></li>
					<li><strong>Filter by Tags:</strong> <code>[tapgoods-inventory tags="your-tag, your-tag"]</code></li>
					<li><strong>Hide Inventory Filters:</strong> <code>[tapgoods-inventory show_filters="false"]</code></li>
					<li><strong>Hide Item Pricing:</strong> <code>[tapgoods-inventory show_pricing="false"]</code></li>
					<li><strong>Items Per Page:</strong> <code>[tapgoods-inventory items_per_page="24"]</code> (12, 24, 36, or <code>all</code> to show every item without pagination)</li>
					<li><strong>Combine Modifiers:</strong> <code>[tapgoods-inventory tags="Blush-Wedding" show_filters="false"]</code></li>
				</ul>
			</div>
			
			<!-- Preview -->
			<div class="col-md-4 text-center">
			<div class="tapgoods-inventory-preview"></div>
			</div>
		</div>
	</div>
</div>
	<hr class="my-4">

    <!-- Row 2 -->

	<div class="row mb-3">
	<!-- Column for the title -->
	<div class="col-md-2">
		<h3 class="fw-bold active" style="color: var(--tg-blue);">Select Location</h3>

	</div>
	
	<!-- Column for the content and preview -->
	<div class="col-md-10">
		<div class="row">
			<!-- Content -->
			<div class="col-md-8">
				<form>
					<div class="input-group mb-3">
						<span id="tapgoods-location-select-input" class="form-control tapgoods-shortcode-display" role="textbox" aria-readonly="true" aria-label="Select Location shortcode" tabindex="0" data-shortcode="[tapgoods-location-select]">[tapgoods-location-select]</span>
						<button type="button" onClick="copyText('tapgoods-location-select-input')"
								data-bs-toggle="tooltip" data-bs-placement="bottom"
								data-bs-title="Copy to clipboard"
								aria-label="Copy Select Location shortcode to clipboard"
								class="btn btn-outline-secondary">
							<span class="dashicons dashicons-admin-page"></span>
						</button>
					</div>
				</form>
				<p class="text-muted">Add a LOCATION SELECTOR dropdown.</p>
			</div>
			
			<!-- Preview -->
			<div class="col-md-4 text-center">
				<select class="form-select rounded-pill">
                    <option>Location</option>
                </select>
			</div>
		</div>
	</div>
</div>


<hr class="my-4">
<!-- Row 3 -->

<div class="row mb-3">
	<!-- Column for the title -->
	<div class="col-md-2">
		<h3 class="fw-bold active" style="color: var(--tg-blue);">Cart Button</h3>

	</div>
	
	<!-- Column for the content and preview -->
	<div class="col-md-10">
		<div class="row">
			<!-- Content -->
			<div class="col-md-8">
				<form>
					<div class="input-group mb-3">
						<span id="tapgoods-cart-input" class="form-control tapgoods-shortcode-display" role="textbox" aria-readonly="true" aria-label="Cart Button shortcode" tabindex="0" data-shortcode="[tapgoods-cart]">[tapgoods-cart]</span>
						<button type="button" onClick="copyText('tapgoods-cart-input')"
								data-bs-toggle="tooltip" data-bs-placement="bottom"
								data-bs-title="Copy to clipboard"
								aria-label="Copy Cart Button shortcode to clipboard"
								class="btn btn-outline-secondary">
							<span class="dashicons dashicons-admin-page"></span>
						</button>
					</div>
				</form>
				<p class="text-muted">
				Add a CART icon to your navigation.
				</p>

			</div>
			
			<!-- Preview -->
			<div class="col-md-4 text-center">
			<svg class="tg-primary" width="30" height="23" viewBox="0 0 30 23" xmlns="http://www.w3.org/2000/svg">
					<path fill-rule="evenodd" clip-rule="evenodd" d="M6.07816 0.807775L7.03594 3.85529H28.8805C28.9977 3.8538 29.1144 3.87089 29.2262 3.90597C29.8084 4.08852 30.1319 4.70693 29.9488 5.28725L26.6334 16.2289C26.4773 16.6856 26.0492 16.9947 25.5651 17H9.61455C9.13636 17.0021 8.71503 16.6871 8.5831 16.2289L4.19946 2.20302H0V0H5.04672C5.53101 0.0147633 5.94916 0.342272 6.07816 0.807775ZM12.5531 18.0006C11.1727 17.9713 10.0299 19.0666 10.0006 20.447C9.97129 21.8274 11.0666 22.9701 12.447 22.9994C13.8273 23.0287 14.9701 21.9335 14.9995 20.5531C15 20.5267 15.0002 20.5003 14.9998 20.474C15.0146 19.1227 13.9311 18.0154 12.5798 18.0007L12.5531 18.0006ZM21.5797 18.0013C20.1996 17.9573 19.0453 19.0403 19.0013 20.4203C18.9573 21.8003 20.0403 22.9547 21.4204 22.9987C22.8004 23.0427 23.9547 21.9597 23.9987 20.5796C23.9998 20.5447 24.0002 20.5097 23.9999 20.4747C24.0146 19.1234 22.9312 18.0161 21.58 18.0013H21.5797Z" fill="currentColor" />
				</svg>
			</div>
		</div>
	</div>
</div>

<hr class="my-4">
<!-- Row 4 -->

<div class="row mb-3">
	<!-- Column for the title -->
	<div class="col-md-2">
		<h3 class="fw-bold active" style="color: var(--tg-blue);">Sign In Link</h3>

	</div>
	
	<!-- Column for the content and preview -->
	<div class="col-md-10">
		<div class="row">
			<!-- Content -->
			<div class="col-md-8">
				<form>
					<div class="input-group mb-3">
						<span id="tapgoods-sign-in-input" class="form-control tapgoods-shortcode-display" role="textbox" aria-readonly="true" aria-label="Sign In Link shortcode" tabindex="0" data-shortcode="[tapgoods-sign-in]">[tapgoods-sign-in]</span>
						<button type="button" onClick="copyText('tapgoods-sign-in-input')"
								data-bs-toggle="tooltip" data-bs-placement="bottom"
								data-bs-title="Copy to clipboard"
								aria-label="Copy Sign In Link shortcode to clipboard"
								class="btn btn-outline-secondary">
							<span class="dashicons dashicons-admin-page"></span>
						</button>
					</div>
				</form>
				<p class="text-muted">
				Add a SIGN IN icon to your navigation.
				</p>
			</div>
			
			<!-- Preview -->
			<div class="col-md-4 text-center">
			<a href="#" class="text-decoration-underline">Sign In</a>
			</div>
		</div>
	</div>
</div>


<hr class="my-4">
<!-- Row 5 -->

<div class="row mb-3">
	<!-- Column for the title -->
	<div class="col-md-2">
		<h3 class="fw-bold active" style="color: var(--tg-blue);">Sign Up Link</h3>

	</div>
	
	<!-- Column for the content and preview -->
	<div class="col-md-10">
		<div class="row">
			<!-- Content -->
			<div class="col-md-8">
				<form>
					<div class="input-group mb-3">
						<span id="tapgoods-sign-up-input" class="form-control tapgoods-shortcode-display" role="textbox" aria-readonly="true" aria-label="Sign Up Link shortcode" tabindex="0" data-shortcode="[tapgoods-sign-up]">[tapgoods-sign-up]</span>
						<button type="button" onClick="copyText('tapgoods-sign-up-input')"
								data-bs-toggle="tooltip" data-bs-placement="bottom"
								data-bs-title="Copy to clipboard"
								aria-label="Copy Sign Up Link shortcode to clipboard"
								class="btn btn-outline-secondary">
							<span class="dashicons dashicons-admin-page"></span>
						</button>
					</div>
				</form>
				<p class="text-muted">
				Add a SIGN UP icon to your navigation.
				</p>
			</div>
			
			<!-- Preview -->
			<div class="col-md-4 text-center">
				<a href="#" class="text-decoration-underline">Sign Up</a>
			</div>
		</div>
	</div>
</div>


<hr class="my-4">
<!-- Row 6 -->

<div class="row mb-3">
	<!-- Column for the title -->
	<div class="col-md-2">
		<h3 class="fw-bold active" style="color: var(--tg-blue);">Search Bar</h3>

	</div>

	<!-- Column for the content and preview -->
	<div class="col-md-10">
		<div class="row">
			<!-- Content -->
			<div class="col-md-8">
				<form>
					<div class="input-group mb-3">
						<span id="tapgoods-search-bar-input" class="form-control tapgoods-shortcode-display" role="textbox" aria-readonly="true" aria-label="Search Bar shortcode" tabindex="0" data-shortcode="[tapgoods-search-bar]">[tapgoods-search-bar]</span>
						<button type="button" onClick="copyText('tapgoods-search-bar-input')"
								data-bs-toggle="tooltip" data-bs-placement="bottom"
								data-bs-title="Copy to clipboard"
								aria-label="Copy Search Bar shortcode to clipboard"
								class="btn btn-outline-secondary">
							<span class="dashicons dashicons-admin-page"></span>
						</button>
					</div>
				</form>
				<p class="text-muted">
				Add a SEARCH BAR to your header or navigation. Visitors can search from any page and land on your shop page with the results.
				</p>
				<p style="color: var(--tg-blue);"><strong>Shortcode Modifiers:</strong></p>
				<ul class="text-muted">
					<li><strong>Placeholder Text:</strong> <code>[tapgoods-search-bar placeholder="Search tents, linens..."]</code></li>
					<li><strong>Button Text Instead of Icon:</strong> <code>[tapgoods-search-bar button_text="Search"]</code></li>
					<li><strong>Results Page:</strong> <code>[tapgoods-search-bar action_url="https://yoursite.com/shop/"]</code> (only needed if your shop page isn't found automatically)</li>
				</ul>
			</div>

			<!-- Preview -->
			<div class="col-md-4 text-center">
				<div class="input-group input-group-sm">
					<input type="text" class="form-control" placeholder="Search rentals" disabled>
					<span class="input-group-text"><span class="dashicons dashicons-search"></span></span>
				</div>
			</div>
		</div>
	</div>
</div>
</div>


<?php
// Copy functionality is now handled by tapgoods-admin-complete.js
?>










