<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Initialize connection information and variables
$tg_api  = Tapgoods_Connection::get_instance();
$api_key = $tg_api->get_key();

$connected       = ( ! empty( get_option( 'tg_api_connected', false ) ) );
$button_text     = ( $connected ) ? 'CONNECTED' : 'CONNECT';
$key_disabled    = ( defined( 'TAPGOODS_KEY' ) ) ? 'disabled' : '';
$button_disabled = ( defined( 'TAPGOODS_KEY' ) || '' !== $api_key ) ? 'disabled' : '';
$sync_hidden     = ( $connected ) ? '' : 'hidden style="display: none !important;"';

// Check if a reset occurred
$reset_done = get_option('tapgreino_reset_done', false);

// Handle the "Reset to Default" action
if (isset($_POST['confirm_reset'])) {
    delete_option('tg_key'); 
    delete_option('tg_api_connected');
    delete_option('tg_location_settings'); 
    delete_option('tapgreino_default_location');
    delete_option('tg_locationIds');
    delete_option('tg_businessId');
    delete_option('tg_last_api_key');
    delete_option('tg_last_sync_progress');
    delete_option('tg_last_sync_info');
    delete_option('tg_cart_url_with_redirect');
    delete_option('tg_sync_state');

    // Delete all categories and tags
    $taxonomies = ['tg_category', 'tg_tags', 'tg_location'];
    foreach ($taxonomies as $taxonomy) {
        $terms = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false, 'fields' => 'ids']);
        foreach ($terms as $term_id) {
            wp_delete_term($term_id, $taxonomy);
        }
    }

    // Delete all inventory items
    $args = ['post_type' => 'tg_inventory', 'numberposts' => -1, 'fields' => 'ids', 'post_status' => 'any'];
    $posts = get_posts($args);
    foreach ($posts as $post_id) {
        wp_delete_post($post_id, true);
    }

    update_option('tapgreino_reset_done', true);
    $connected = false;
    echo '<p class="tapgoods-success">All data has been successfully deleted.</p>';
    wp_add_inline_script('tapgoods-admin-complete', 'showSuccessMessage();');
    exit;
}

// Cart redirect URL (post submission). The CART_URL_WITH_REDIRECT constant in wp-config.php overrides the saved option.
$redirect_from_config = defined( 'CART_URL_WITH_REDIRECT' );
$redirect_message     = '';
$redirect_error       = false;

if (
	! $redirect_from_config
	&& isset( $_POST['tapgrein_save_cart_redirect'], $_POST['_tgnonce_cart_redirect'] )
	&& current_user_can( 'manage_options' )
	&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_tgnonce_cart_redirect'] ) ), 'save' )
) {
	$submitted_redirect = isset( $_POST['tg_cart_url_with_redirect'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['tg_cart_url_with_redirect'] ) ) ) : '';

	if ( '' === $submitted_redirect ) {
		delete_option( 'tg_cart_url_with_redirect' );
		$redirect_message = __( 'Cart redirect URL cleared.', 'tapgoods' );
	} elseif ( '' !== tapgrein_validate_redirect_url( $submitted_redirect ) ) {
		update_option( 'tg_cart_url_with_redirect', esc_url_raw( $submitted_redirect ) );
		$redirect_message = __( 'Cart redirect URL saved.', 'tapgoods' );
	} else {
		$redirect_error   = true;
		$redirect_message = __( 'Please enter a valid URL starting with http:// or https://. The setting was not changed.', 'tapgoods' );
	}
}

$redirect_value = defined( 'CART_URL_WITH_REDIRECT' ) ? (string) CART_URL_WITH_REDIRECT : (string) get_option( 'tg_cart_url_with_redirect', '' );
?>

<h2>Connect to your TapGoods account</h2>
<form name="tapgoods_connection" id="tapgrein_connection_form" method="post" action="" autocomplete="off">
    <input type="hidden" name="tapgoods_hidden" value="1">
    <?php wp_nonce_field( 'save', '_tgnonce_connection' ); ?>
    <div class="row">
        <div class="col col-sm-6">
            <?php
            /**
             * autocomplete="new-password" (not "off") on the field itself: password
             * managers ignore autocomplete="off" on password inputs, but "new-password"
             * is the documented signal that tells them not to offer to fill or save
             * this field. This matters more since WPB-167 -- with the shortcode boxes
             * no longer real <input>s, this is the only text-like field left on the
             * page, so a manager that was filling the shortcode box could instead
             * offer the admin's own WordPress login here, and a "save password" prompt
             * would post the admin's WP credentials to whatever the manager considers
             * the form target.
             */
            ?>
            <input type="password" id="tapgoods_api_key" name="tapgoods_api_key" value="<?php echo esc_attr( $api_key ); ?>" size="60" class="form-control round api-key" autocomplete="new-password" <?php echo esc_attr( $key_disabled ); ?>>
        </div>
        <div class="col col-sm-3">
            <button type="submit" name="submit" id="tapgrein_update_connection" value="tapgrein_update_connection" class="btn btn-primary bg-blue w-100 round" <?php echo esc_attr( $button_disabled ); ?>>
                <?php echo esc_html( $button_text ); ?>
            </button>
        </div>
        <div class="col col-sm-3">
            <button type="button" name="tapgrein_sync" id="tapgrein_api_sync" value="tapgrein_api_sync" class="btn btn-primary w-100 round" <?php echo esc_attr( $sync_hidden ); ?>>SYNC</button>
        </div>
    </div>

    <?php if ( '' !== $key_disabled || $reset_done  || get_option( 'tg_api_connected' ) == false ) { ?>
        <!-- Show message for API key generation -->
        <p class="help-text"> Generate an API key in your <a href="https://business.tapgoods.com/admin/storefront/wordpress" target="_blank">TapGoods WordPress Settings</a> </p>
        <p> <span style="font-weight: bold; color: #d63638; margin: 0;">Important note:</span> This key is only generated once and won't be displayed again. <br>
        Make sure to copy and save it immediately in a secure place.</p>       
        <?php if ($reset_done) delete_option('tapgreino_reset_done'); ?>
    <?php } elseif ($connected) { ?>
        <p class="help-text">Your site is connected to TapGoods. To generate a new API key, please contact <a href="mailto:support@tapgoods.com">support@tapgoods.com</a>.</p>
    <?php } ?>
</form>

<!-- Sync Status Message -->
<div id="tapgrein_connection_test">
    <?php
    $sync_message = $tg_api->last_sync_message();
    if ($sync_message && get_option('tg_api_connected')) :
        echo wp_kses(wpautop($sync_message), 'post');
    endif;
    ?>
</div>

<?php
// Sync state machine status panel.
if ( $connected ) :
    $tg_state   = $tg_api->sync_state();
    $tg_summary = $tg_state->get_summary();
    $tg_fmt     = static function ( $ts ) {
        return $ts ? esc_html( date_i18n( 'M j, Y g:i a', (int) $ts ) ) : 'Never';
    };
    ?>
    <div id="tapgrein_sync_status" class="tapgrein-sync-status" data-state="<?php echo esc_attr( $tg_summary['state'] ); ?>">
        <h3>Sync Status</h3>
        <table class="widefat striped" style="max-width:640px;">
            <tbody>
                <tr>
                    <th scope="row">Current state</th>
                    <td><span id="tapgrein_sync_state_label"><?php echo esc_html( $tg_summary['label'] ); ?></span></td>
                </tr>
                <tr>
                    <th scope="row">Currently</th>
                    <td>
                        <span id="tapgrein_sync_activity">
                            <?php
                            // Fall back to the state label rather than rendering an empty
                            // row. A plugin distributed as a zip gets unpacked over a
                            // running site, and a host with a persistent opcache can serve
                            // a stale compiled copy of one file while another is already
                            // new, which is exactly how this row showed up blank once.
                            echo esc_html(
                                isset( $tg_summary['activity'] ) && '' !== $tg_summary['activity']
                                    ? $tg_summary['activity']
                                    : $tg_summary['label']
                            );
                            ?>
                        </span>
                    </td>
                </tr>
                <tr>
                    <?php
                    // Deliberately not called "progress": this counts item pages only, and a
                    // run spends whole phases (categories, then finalize) at 0/N and N/N. The
                    // "Currently" row above is what says where the run actually is.
                    ?>
                    <th scope="row">Item pages fetched</th>
                    <td><?php echo esc_html( $tg_summary['pages_completed'] . ' / ' . $tg_summary['total_pages'] ); ?></td>
                </tr>
                <tr>
                    <th scope="row">Last successful sync</th>
                    <td><?php echo $tg_fmt( $tg_summary['last_success'] ); ?></td>
                </tr>
                <tr>
                    <th scope="row">Last error</th>
                    <td>
                        <?php echo $tg_fmt( $tg_summary['last_error'] ); ?>
                        <?php if ( ! empty( $tg_summary['error_message'] ) ) : ?>
                            <br><em><?php echo esc_html( $tg_summary['error_message'] ); ?></em>
                        <?php endif; ?>
                        <?php if ( $tg_summary['failure_count'] > 0 ) : ?>
                            <br><small>Attempts failed: <?php echo esc_html( $tg_summary['failure_count'] . ' (retries before error: ' . $tg_summary['max_retries'] . ')' ); ?></small>
                        <?php endif; ?>
                    </td>
                </tr>
            </tbody>
        </table>
        <p>
            <button type="button" id="tapgrein_clear_sync_errors" class="btn btn-secondary round"
                <?php echo $tg_summary['has_error'] ? '' : 'style="display:none;"'; ?>>
                Clear Errors
            </button>
        </p>
    </div>
<?php endif; ?>

<!-- Sync progress modal -->
<div id="syncProgressModal" class="overlay" style="display: none;">
    <div class="popup sync-popup">
        <div class="sync-icon">
            <span class="spinner-border spinner-border-lg text-primary" role="status" aria-hidden="true"></span>
        </div>
        <h2>Synchronization in Progress</h2>
        <p>We're syncing your inventory and locations from TapGoods. This runs one batch now and then continues automatically in the background, so large catalogs keep syncing after this window closes.</p>
        <div class="sync-details">
            <p><strong>What we're doing:</strong></p>
            <ul>
                <li>✓ Fetching categories and tags</li>
                <li>✓ Updating inventory items</li>
                <li>✓ Syncing location data</li>
                <li>✓ Processing images and metadata</li>
            </ul>
        </div>
        <p class="sync-warning"><strong>Good to know:</strong> You can safely leave this page. The sync continues in the background and its progress is shown under "Sync Status" below.</p>
        <div id="syncProgressStatus" class="sync-status">
            <p>Initializing synchronization...</p>
        </div>
    </div>
</div>

<!-- Reset confirmation popup -->
<div id="popup" class="overlay" style="display: none;">
    <div class="popup">
        <h1>Are you sure you want to reset to default?</h1>
        <p>This will disconnect your website from TapGoods and delete all inventory from your website. This action cannot be undone.</p>
        <form method="post">
            <button type="submit" name="confirm_reset" class="btn btn-danger">Yes, Reset to Default</button>
            <button type="button" class="btn btn-secondary" onclick="closePopup();">Cancel</button>
        </form>
    </div>
</div>

<p class="help-text">
    <a href="javascript:void(0);" onclick="openPopup()">Reset to Default</a>
</p>

<hr>

<form name="tapgoods_cart_redirect" id="tapgrein_cart_redirect_form" method="post" action="">
	<?php wp_nonce_field( 'save', '_tgnonce_cart_redirect' ); ?>
	<label for="tg_cart_url_with_redirect" class="form-label fw-bold">Cart Redirect URL Post Submission</label>
	<div class="row">
		<div class="col col-sm-6">
			<input type="url" id="tg_cart_url_with_redirect" name="tg_cart_url_with_redirect" value="<?php echo esc_attr( $redirect_value ); ?>" placeholder="https://yoursite.whatever/thepageyouwantredirectedto" class="form-control round" <?php disabled( $redirect_from_config ); ?>>
		</div>
		<div class="col col-sm-3">
			<button type="submit" name="tapgrein_save_cart_redirect" value="1" class="btn btn-primary bg-blue w-100 round" <?php disabled( $redirect_from_config ); ?>>SAVE</button>
		</div>
	</div>
	<?php if ( $redirect_from_config ) : ?>
		<p class="help-text">This value is set by the CART_URL_WITH_REDIRECT constant in wp-config.php and can only be changed there.</p>
	<?php else : ?>
		<p class="help-text">After a customer submits their cart, TapGoods sends them to this page. Leave empty to keep the default behavior.</p>
	<?php endif; ?>
	<?php if ( '' !== $redirect_message ) : ?>
		<?php if ( $redirect_error ) : ?>
			<p class="help-text" style="font-weight: bold; color: #d63638;"><?php echo esc_html( $redirect_message ); ?></p>
		<?php else : ?>
			<p class="tapgoods-success"><?php echo esc_html( $redirect_message ); ?></p>
		<?php endif; ?>
	<?php endif; ?>
</form>
