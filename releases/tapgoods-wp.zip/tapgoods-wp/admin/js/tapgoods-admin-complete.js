/**
 * TapGoods Admin - Complete JavaScript Functions
 * Refactored from inline scripts to proper WordPress enqueue system
 */

// Initialize all admin functions when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    initAdminPermalinks();
    initAdminConnection();
    initAdminShortcodes();
    initAdminOptions();
    initAdminStatus();
    initTinyMCEEditor();
    initColorPicker();
    initTagFocus();
    initSyncButton();
    initInventorySync();
    initClearSyncErrors();
});

/**
 * Clear Errors button - resets a latched sync error via AJAX.
 */
function initClearSyncErrors() {
    const clearButton = document.getElementById('tapgrein_clear_sync_errors');
    if (!clearButton) {
        return;
    }

    clearButton.addEventListener('click', function(e) {
        e.preventDefault();

        clearButton.disabled = true;
        const originalText = clearButton.textContent;
        clearButton.textContent = 'Clearing...';

        const formData = new FormData();
        formData.append('action', 'tapgrein_clear_sync_errors');
        formData.append('nonce', (typeof tg_admin_vars !== 'undefined' && tg_admin_vars.sync_nonce) ? tg_admin_vars.sync_nonce : '');

        fetch(tg_admin_vars.ajaxurl, {
            method: 'POST',
            credentials: 'same-origin',
            body: formData
        })
        .then(response => response.json())
        .then(response => {
            if (response.success) {
                // Hide the button and reflect the reset state in the panel.
                clearButton.style.display = 'none';
                const label = document.getElementById('tapgrein_sync_state_label');
                if (label && response.data && response.data.state) {
                    label.textContent = response.data.state.label;
                }
                // Keep the "Currently" line in step with the state it describes.
                const activity = document.getElementById('tapgrein_sync_activity');
                if (activity && response.data && response.data.state && response.data.state.activity) {
                    activity.textContent = response.data.state.activity;
                }
                showConnectionNotice('Sync errors cleared.', 'success');
            } else {
                clearButton.disabled = false;
                clearButton.textContent = originalText;
                const message = response.data || 'Unable to clear errors. Please try again.';
                showConnectionNotice(message, 'error');
            }
        })
        .catch(() => {
            clearButton.disabled = false;
            clearButton.textContent = originalText;
            showConnectionNotice('Unable to clear errors. Please try again.', 'error');
        });
    });
}

/**
 * Admin Permalinks - from admin/class-tapgoods-admin-permalinks.php:129
 */
function initAdminPermalinks() {
    if (typeof tapgoodsPermalinks !== 'undefined') {
        // Admin permalinks functionality will be added via wp_add_inline_script
        console.log('TapGoods: Admin permalinks initialized');
    }
}

/**
 * Admin Connection Handling - from admin/partials/tapgoods-admin-connection.php
 */
function initAdminConnection() {
    const connectForm = document.getElementById('tapgrein_connection_form');
    const connectButton = document.getElementById('tapgrein_update_connection');
    const connectInput = document.getElementById('tapgoods_api_key');
    const syncButton = document.getElementById('tapgrein_api_sync');
    
    if (!connectForm || !connectButton || !connectInput || !syncButton) {
        console.log('TapGoods: Connection form elements not found on this page');
        return;
    }
    
    console.log('TapGoods: Initializing admin connection');
    
    // Check if we need to show sync success message
    checkForSyncSuccess();
    
    // Store original values
    const originalApiKey = connectInput.value;
    connectInput.setAttribute('data-original', originalApiKey);
    connectButton.setAttribute('data-original', connectButton.textContent);
    
    // Set initial state based on button text (CONNECTED means API is connected)
    const isConnected = connectButton.textContent.trim() === 'CONNECTED';
    console.log('TapGoods: Initial connection state:', isConnected);
    
    if (!isConnected) {
        // Ensure sync button is hidden if not connected
        syncButton.style.display = 'none';
        syncButton.setAttribute('hidden', 'hidden');
    } else {
        // Ensure sync button is visible if connected
        syncButton.style.display = 'inline-block';
        syncButton.removeAttribute('hidden');
    }
    
    // Handle input changes for the API key
    connectInput.addEventListener('input', function(e) {
        if (e.target.value === e.target.getAttribute('data-original')) {
            connectButton.disabled = true;
            connectButton.textContent = connectButton.getAttribute('data-original');
            if (e.target.value !== '') {
                syncButton.style.display = 'inline-block';
                syncButton.removeAttribute('hidden');
            }
        } else {
            connectButton.disabled = false;
            connectButton.textContent = 'CONNECT';
            syncButton.style.display = 'none';
            syncButton.setAttribute('hidden', 'hidden');
        }
    });
    
    // Form submission event
    connectForm.addEventListener('submit', function(e) {
        e.preventDefault();
        handleConnection(connectButton, connectInput, syncButton);
    });
    
    // Sync button handler
    syncButton.addEventListener('click', function(e) {
        e.preventDefault();
        handleSync(syncButton);
    });
}

/**
 * Handle API connection
 */
function handleConnection(connectButton, connectInput, syncButton) {
    connectButton.disabled = true;
    connectButton.innerHTML = '<span class="spinner-border spinner-border-sm" aria-hidden="true"></span> CONNECTING';
    
    const formData = new FormData(document.getElementById('tapgrein_connection_form'));
    formData.append('action', 'tapgrein_update_connection');
    
    console.log('TapGoods: Submitting connection request');
    
    fetch(tg_admin_vars.ajaxurl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(response => {
        console.log('TapGoods: Connection response:', response);
        
        if (response.success) {
            connectButton.disabled = true;
            connectButton.textContent = 'CONNECTED';
            connectInput.setAttribute('data-original', connectInput.value);
            connectInput.setAttribute('value', connectInput.value);
            
            // Show sync button - remove hidden attribute and display style
            syncButton.style.display = 'inline-block';
            syncButton.removeAttribute('hidden');
            
            // Show success message in response data
            if (response.data) {
                showConnectionNotice(response.data, 'success');
            }
            
            // Show visual feedback that connection succeeded
            showSuccessMessage('API connection successful!');
            
        } else {
            connectButton.disabled = false;
            connectButton.textContent = 'CONNECT';
            syncButton.style.display = 'none';
            syncButton.setAttribute('hidden', 'hidden');
            
            // Show error message
            if (response.data) {
                showConnectionNotice(response.data, 'error');
            }
        }
    })
    .catch(error => {
        console.error('TapGoods: Connection error:', error);
        connectButton.disabled = false;
        connectButton.textContent = 'CONNECT';
        syncButton.style.display = 'none';
        syncButton.setAttribute('hidden', 'hidden');
        showSuccessMessage('Connection failed. Please try again.', 'error');
    });
}

/**
 * Handle API sync
 */
function handleSync(syncButton) {
    const nonce = document.getElementById('_tgnonce_connection').value;
    const statusEl = document.getElementById('tapgrein_connection_test');

    // Show sync progress modal
    showSyncProgressModal();

    syncButton.disabled = true;
    syncButton.innerHTML = '<span class="spinner-border spinner-border-sm" aria-hidden="true"></span> WORKING';

    // The manual sync is non-blocking: this request runs a single bounded slice,
    // then WP-Cron continues the rest in the background. So we only report what
    // this one slice did and hand the run off, rather than pretending the whole
    // sync happens in this request.
    updateSyncStatus('Starting sync. This runs one batch, then continues in the background...');

    const url = `${tg_admin_vars.ajaxurl}?action=tapgrein_api_sync&_tgnonce_connection=${nonce}`;

    // Helper: normalise the wp_send_json_* payload, which may be a structured
    // object ({ message, in_progress, state }) or, on older/error paths, a string.
    const readData = (response) => {
        const data = response && typeof response.data === 'object' && response.data !== null ? response.data : {};
        const message = (response && typeof response.data === 'string') ? response.data : (data.message || '');
        return { data, message, inProgress: !!data.in_progress, state: data.state || null };
    };

    // Reload so the server-rendered "Sync Status" panel reflects the current
    // state machine (state + planned-vs-completed pages). A simple status read
    // beats a bespoke polling loop here.
    const reloadSoon = (markSuccess) => {
        setTimeout(() => {
            const next = new URL(window.location.href);
            if (markSuccess) {
                next.searchParams.set('sync_success', '1');
            } else {
                next.searchParams.delete('sync_success');
            }
            window.location.href = next.toString();
        }, 1800);
    };

    fetch(url)
    .then(response => response.json())
    .then(response => {
        console.log('TapGoods: Sync response:', response);

        const { message, inProgress, state } = readData(response);

        if (response.success) {
            const pages = state ? `${state.pages_completed} of ${state.total_pages}` : null;

            // Still running: this slice checkpointed and cron will carry on. Do NOT
            // claim the sync finished.
            if (inProgress || (state && (state.state === 'active' || state.state === 'prep'))) {
                const note = pages
                    ? `Sync is running in the background (${pages} pages done). You can safely leave this page; it will keep syncing.`
                    : 'Sync is running in the background. You can safely leave this page; it will keep syncing.';
                updateSyncStatus(note);
                if (statusEl) {
                    showConnectionNotice(note, 'info');
                }
                reloadSoon(false);
                return;
            }

            // Nothing to sync (already up to date).
            if (message && message.includes('Nothing to sync')) {
                updateSyncStatus(message);
                if (statusEl) {
                    showConnectionNotice(message, 'success');
                }
                reloadSoon(false);
                return;
            }

            // Completed fully within this one slice.
            updateSyncStatus('Synchronization completed successfully!');
            reloadSoon(true);
        } else {
            const errorMessage = message || 'Synchronization failed. Please try again.';
            updateSyncStatus('Synchronization failed: ' + errorMessage);
            setTimeout(() => {
                hideSyncProgressModal();
                syncButton.disabled = false;
                syncButton.textContent = 'SYNC';

                if (statusEl) {
                    showConnectionNotice(errorMessage, 'error');
                }
            }, 2000);
        }
    })
    .catch(error => {
        console.error('TapGoods: Sync error:', error);
        const errorMessage = error.message || 'Connection error occurred. Please check your internet connection and try again.';
        updateSyncStatus(errorMessage);

        setTimeout(() => {
            hideSyncProgressModal();
            syncButton.disabled = false;
            syncButton.textContent = 'SYNC';

            if (statusEl) {
                showConnectionNotice('Synchronization failed. Please try again.', 'error');
            }
        }, 2000);
    });
}

/**
 * Show sync progress modal
 */
function showSyncProgressModal() {
    const modal = document.getElementById('syncProgressModal');
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden'; // Prevent scrolling
        console.log('TapGoods: Sync progress modal shown');
    }
}

/**
 * Hide sync progress modal
 */
function hideSyncProgressModal() {
    const modal = document.getElementById('syncProgressModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = ''; // Restore scrolling
        console.log('TapGoods: Sync progress modal hidden');
    }
}

/**
 * Update sync status message
 */
function updateSyncStatus(message) {
    const statusEl = document.getElementById('syncProgressStatus');
    if (statusEl) {
        statusEl.innerHTML = `<p>${message}</p>`;
        console.log('TapGoods: Sync status updated:', message);
    }
}

/**
 * Enable page close protection during sync
 */
function enableSyncProtection() {
    window.addEventListener('beforeunload', syncProtectionHandler);
    console.log('TapGoods: Sync protection enabled');
}

/**
 * Disable page close protection after sync
 */
function disableSyncProtection() {
    window.removeEventListener('beforeunload', syncProtectionHandler);
    console.log('TapGoods: Sync protection disabled');
}

/**
 * Handler for sync protection
 */
function syncProtectionHandler(e) {
    const message = 'Synchronization is in progress. Are you sure you want to leave? This may interrupt the process.';
    e.preventDefault();
    e.returnValue = message;
    return message;
}

/**
 * Check for sync success parameter and show message
 */
function checkForSyncSuccess() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('sync_success') === '1') {
        // Remove the parameter from URL to avoid showing message on refresh
        const url = new URL(window.location.href);
        url.searchParams.delete('sync_success');
        history.replaceState({}, document.title, url.toString());
        
        // Show success message
        setTimeout(() => {
            showSuccessMessage('Synchronization completed successfully! Your inventory and locations have been updated.', 'success');
        }, 500);
        
        console.log('TapGoods: Sync success message displayed');
    }
}

/**
 * Show connection notice
 */
function showConnectionNotice(message, type = 'success') {
    const statusEl = document.getElementById('tapgrein_connection_test');
    if (statusEl) {
        statusEl.innerHTML = `<div class="notice notice-${type} is-dismissible"><p>${message}</p></div>`;
    }
}

/**
 * Admin Connection Success Messages - from admin/partials/tapgoods-admin-connection.php:48
 */
function showSuccessMessage(message = null, type = 'success') {
    let messageElement = document.querySelector('.tapgoods-success');
    
    // If no existing element and we have a message, create one
    if (!messageElement && message) {
        messageElement = document.createElement('div');
        messageElement.className = `tapgoods-${type}`;
        messageElement.style.cssText = `
            background: ${type === 'success' ? '#d4edda' : '#f8d7da'};
            border: 1px solid ${type === 'success' ? '#c3e6cb' : '#f5c6cb'};
            color: ${type === 'success' ? '#155724' : '#721c24'};
            padding: 15px;
            margin: 10px 0;
            border-radius: 4px;
            display: block;
        `;
        
        // Insert after the form
        const form = document.getElementById('tapgrein_connection_form');
        if (form && form.parentNode) {
            form.parentNode.insertBefore(messageElement, form.nextSibling);
        }
    }
    
    if (messageElement) {
        if (message) {
            messageElement.textContent = message;
        }
        messageElement.style.display = 'block';
        setTimeout(function() {
            if (messageElement.parentNode) {
                messageElement.style.display = 'none';
            }
        }, 5000);
    }
}

/**
 * Admin Shortcodes Copy Functions - from admin/partials/tapgoods-admin-shortcodes.php:221
 */
function initAdminShortcodes() {
    // Copy shortcode to clipboard function
    window.copyText = function(elementId) {
        const input = document.getElementById(elementId);
        if (!input) {
            console.error("TapGoods Admin: Input element not found with ID: " + elementId);
            return;
        }

        // Read from the authoritative data-shortcode attribute first (see WPB-167:
        // a form input here could be silently overwritten by a browser password
        // manager / autofill, which copied the wrong value). Fall back to .value /
        // .textContent so this stays backward-compatible with any other element
        // copyText() might be pointed at.
        const textToCopy = (input.dataset && typeof input.dataset.shortcode === 'string')
            ? input.dataset.shortcode
            : (typeof input.value === 'string' && input.value !== '' ? input.value : (input.textContent || '').trim());

        const button = document.querySelector(`button[onclick*="${elementId}"]`);
        const originalButtonContent = button ? button.innerHTML : null;
        
        // Function to show visual feedback
        function showCopyFeedback(success = true) {
            if (button) {
                button.innerHTML = success ? "Copied!" : "Failed";
                button.style.background = success ? "#28a745" : "#dc3545";
                button.style.color = "#fff";
                setTimeout(function() {
                    button.innerHTML = originalButtonContent;
                    button.style.background = "";
                    button.style.color = "";
                }, 1500);
            }
        }
        
        // Try modern clipboard API first
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(textToCopy).then(() => {
                console.log("TapGoods Admin: Copied to clipboard: " + textToCopy);
                showCopyFeedback(true);
            }).catch(err => {
                console.error("TapGoods Admin: Modern clipboard failed: ", err);
                // Fall back to legacy method
                fallbackCopy();
            });
        } else {
            // Use fallback method directly
            fallbackCopy();
        }
        
        function fallbackCopy() {
            try {
                // Create a temporary textarea element
                const tempTextarea = document.createElement('textarea');
                tempTextarea.value = textToCopy;
                tempTextarea.style.position = 'fixed';
                tempTextarea.style.left = '-999999px';
                tempTextarea.style.top = '-999999px';
                document.body.appendChild(tempTextarea);
                
                // Select and copy
                tempTextarea.focus();
                tempTextarea.select();
                const successful = document.execCommand('copy');
                
                // Remove temporary element
                document.body.removeChild(tempTextarea);
                
                if (successful) {
                    console.log("TapGoods Admin: Copied using fallback method: " + textToCopy);
                    showCopyFeedback(true);
                } else {
                    console.error("TapGoods Admin: Fallback copy command failed");
                    showCopyFeedback(false);
                }
            } catch (fallbackErr) {
                console.error("TapGoods Admin: Fallback copy also failed: ", fallbackErr);
                showCopyFeedback(false);
            }
        }
    };

    // A real <input> selects its text as soon as you tab to it; a <span> (used here
    // instead so nothing on this tab is a form control autofill can target -- see
    // WPB-167) has no such built-in behaviour. Do it by hand so a keyboard-only user
    // who tabs to one of these boxes can select-all + Ctrl/Cmd+C without touching the
    // mouse or the copy button. `user-select: all` (tg-admin-shortcode-display.css)
    // covers the mouse-drag case; this covers focus.
    document.querySelectorAll('[data-shortcode]').forEach(function (el) {
        el.addEventListener('focus', function () {
            const selection = window.getSelection();
            if (!selection) {
                return;
            }
            const range = document.createRange();
            range.selectNodeContents(el);
            selection.removeAllRanges();
            selection.addRange(range);
        });
    });
}

/**
 * Admin Options Location Storage - from admin/partials/tapgoods-options.php:29
 */
function initAdminOptions() {
    console.log('TapGoods: initAdminOptions called');
    let isSetup = false;
    
    // Try to find the location select element with some delay
    function setupLocationSelect() {
        if (isSetup) return; // Avoid duplicate setup
        
        const locationSelect = document.getElementById('selected_location');
        console.log('TapGoods: Looking for selected_location element...', locationSelect);
        
        if (!locationSelect) {
            console.log('TapGoods: Location select not found on this page');
            return;
        }
        
        console.log('TapGoods: Location select found! Setting up auto-load functionality');
        console.log('TapGoods: Current selected value:', locationSelect.value);
        
        isSetup = true;
        
        // Handle location selection change
        locationSelect.addEventListener('change', function(e) {
            const selectedLocationId = e.target.value;
            console.log('TapGoods: Change event fired! Selected location ID:', selectedLocationId);
            
            if (selectedLocationId) {
                console.log('TapGoods: Valid location selected, auto-loading details...');
                autoLoadLocationDetails();
            } else {
                console.log('TapGoods: No valid location selected');
            }
        });
        
        // Test: Add a click listener as well to make sure events work
        locationSelect.addEventListener('click', function() {
            console.log('TapGoods: Location select clicked');
        });
        
        console.log('TapGoods: Event listeners added to location select');
    }
    
    // Listen for tab show events (Bootstrap tab activation)
    document.addEventListener('shown.bs.tab', function(e) {
        console.log('TapGoods: Tab shown event:', e.target);
        if (e.target.getAttribute('data-bs-target') === '#tapgrein-options') {
            console.log('TapGoods: Multi Location tab activated, setting up location select');
            setTimeout(setupLocationSelect, 100);
        }
    });
    
    // Also listen for simple tab clicks
    const optionsTab = document.getElementById('nav-options-tab');
    if (optionsTab) {
        optionsTab.addEventListener('click', function() {
            console.log('TapGoods: Options tab clicked');
            setTimeout(setupLocationSelect, 200);
        });
    }
    
    // Try immediately, then with delays
    setupLocationSelect();
    setTimeout(setupLocationSelect, 100);
    setTimeout(setupLocationSelect, 500);
    
    // Use MutationObserver to detect when the element appears
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.type === 'childList' && !isSetup) {
                setupLocationSelect();
            }
        });
    });
    
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

/**
 * Auto-load location details via AJAX when dropdown changes
 */
function autoLoadLocationDetails() {
    console.log('TapGoods: autoLoadLocationDetails called');
    
    const locationSelect = document.getElementById('selected_location');
    if (!locationSelect) {
        console.error('TapGoods: Location select not found');
        return;
    }
    
    const selectedLocationId = locationSelect.value;
    console.log('TapGoods: Loading details for location:', selectedLocationId);
    
    // Show loading state
    showLocationDetailsLoading();
    
    // Create form data for the request
    const formData = new FormData();
    formData.append('action', 'load_location_details');
    formData.append('location_id', selectedLocationId);
    formData.append('nonce', tg_admin_vars.sync_nonce || '');
    
    fetch(tg_admin_vars.ajaxurl, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(response => {
        console.log('TapGoods: Location details response:', response);
        
        if (response.success && response.data) {
            updateLocationDetailsSection(response.data);
        } else {
            console.error('TapGoods: Failed to load location details:', response);
            showLocationDetailsError('Failed to load location details. Please try again.');
        }
    })
    .catch(error => {
        console.error('TapGoods: Error loading location details:', error);
        showLocationDetailsError('Connection error. Please try again.');
    });
}

/**
 * Show loading state for location details
 */
function showLocationDetailsLoading() {
    const container = getLocationDetailsContainer();
    if (container) {
        container.innerHTML = `
            <h2 class="mb-4 pt-4 mt-5">Location Details</h2>
            <div class="loading-spinner">
                <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                Loading location details...
            </div>
        `;
    }
}

/**
 * Show error message in location details section
 */
function showLocationDetailsError(message) {
    const container = getLocationDetailsContainer();
    if (container) {
        container.innerHTML = `
            <h2 class="mb-4 pt-4 mt-5">Location Details</h2>
            <div class="alert alert-danger">
                ${message}
            </div>
        `;
    }
}

/**
 * Update the location details section with new data
 */
function updateLocationDetailsSection(data) {
    const container = getLocationDetailsContainer();
    if (container) {
        container.innerHTML = data.html;
        console.log('TapGoods: Location details updated successfully');
    }
}

/**
 * Get or create the location details container
 */
function getLocationDetailsContainer() {
    let container = document.getElementById('location-details-container');
    
    if (!container) {
        // Try to find existing location details section by looking for the h2 with "Location Details"
        const h2Elements = document.querySelectorAll('h2');
        let existingH2 = null;
        
        for (let h2 of h2Elements) {
            if (h2.textContent && h2.textContent.includes('Location Details')) {
                existingH2 = h2;
                break;
            }
        }
        
        if (existingH2) {
            // Create a wrapper container that includes the h2 and all following elements until the end of parent
            container = document.createElement('div');
            container.id = 'location-details-container';
            
            // Insert the container before the h2
            existingH2.parentNode.insertBefore(container, existingH2);
            
            // Move the h2 and all its sibling elements into the container
            let currentElement = existingH2;
            const elementsToMove = [];
            
            // Collect all elements from h2 to the end of the parent
            while (currentElement) {
                elementsToMove.push(currentElement);
                currentElement = currentElement.nextSibling;
            }
            
            // Move all collected elements to the container
            elementsToMove.forEach(el => {
                container.appendChild(el);
            });
        } else {
            // Create new container after the separator div
            const separator = document.querySelector('.position-absolute.start-0.end-0');
            if (separator) {
                container = document.createElement('div');
                container.id = 'location-details-container';
                separator.parentElement.insertBefore(container, separator.nextSibling);
            } else {
                // Fallback: create at the end of the main container
                const mainContainer = document.querySelector('.container');
                if (mainContainer) {
                    container = document.createElement('div');
                    container.id = 'location-details-container';
                    mainContainer.appendChild(container);
                }
            }
        }
    }
    
    return container;
}

/**
 * Admin Status Page Functions - from admin/partials/tapgoods-status.php:98
 */
function initAdminStatus() {
    // Status page specific functionality
    const statusPage = document.querySelector('.tapgoods-status-page');
    if (statusPage) {
        console.log('TapGoods: Admin status page initialized');
    }
}

/**
 * TinyMCE Editor Initialization - from includes/class-tapgoods-post-types.php
 */
function initTinyMCEEditor() {
    if (typeof wp !== 'undefined' && wp.editor) {
        const textareas = document.querySelectorAll('textarea[name="tg_description"]');
        textareas.forEach(function(textarea) {
            if (textarea && !textarea.hasAttribute('data-mce-initialized')) {
                wp.editor.initialize(textarea.id, {
                    tinymce: {
                        wpautop: true,
                        plugins: 'charmap colorpicker hr lists paste tabfocus textcolor fullscreen wordpress wpautoresize wpeditimage wpemoji wpgallery wplink wptextpattern',
                        toolbar1: 'formatselect,bold,italic,bullist,numlist,blockquote,alignleft,aligncenter,alignright,link,wp_more,spellchecker,fullscreen,wp_adv',
                        toolbar2: 'strikethrough,hr,forecolor,pastetext,removeformat,charmap,outdent,indent,undo,redo,wp_help'
                    },
                    quicktags: true,
                    mediaButtons: true
                });
                textarea.setAttribute('data-mce-initialized', 'true');
            }
        });
    }
}

/**
 * Color Picker Initialization - WordPress wp-color-picker
 */
function initColorPicker() {
    if (typeof jQuery !== 'undefined' && jQuery.fn.wpColorPicker) {
        jQuery(function($) {
            $('.color-picker').wpColorPicker();
        });
    }
}

/**
 * Tag Focus Functionality - from includes/tg_edit-tags.php
 */
function initTagFocus() {
    const tagInputs = document.querySelectorAll('input[name="tag-name"]');
    tagInputs.forEach(function(input) {
        if (input) {
            input.focus();
        }
    });
}

/**
 * Sync Button Functionality - from admin connection
 */
function initSyncButton() {
    // This function is now handled by initAdminConnection()
    // Sync button functionality is managed there to avoid conflicts
    console.log('TapGoods: Sync button initialization delegated to connection handler');
}

/**
 * Show sync popup overlay
 */
function showSyncPopup() {
    const overlay = document.querySelector('.overlay');
    if (overlay) {
        overlay.style.display = 'flex';
    }
}

/**
 * Hide sync popup overlay
 */
function hideSyncPopup() {
    const overlay = document.querySelector('.overlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

/**
 * Reset-to-default confirmation popup controls (used by admin/partials/tapgoods-admin-connection.php)
 */
function openPopup() {
    const overlay = document.getElementById('popup');
    if (overlay) {
        overlay.style.display = 'flex';
    }
}

function closePopup() {
    const overlay = document.getElementById('popup');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

/**
 * Inventory Sync AJAX Function
 */
function performInventorySync() {
    // This function is deprecated - sync is now handled by handleSync() in initAdminConnection
    console.log('TapGoods: performInventorySync is deprecated, using handleSync instead');
}

/**
 * Initialize inventory sync
 */
function initInventorySync() {
    console.log('TapGoods: Inventory sync functions initialized');
}