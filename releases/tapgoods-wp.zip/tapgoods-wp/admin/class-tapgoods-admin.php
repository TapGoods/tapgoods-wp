<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Tapgoods
 * @subpackage Tapgoods/admin
 * @author     Aaron Valiente <aaron.valiente@tapgoods.com> and Jeremy Benson <jeremy.benson@tapgoods.com>
 */
class Tapgoods_Admin {

	private $plugin_name;
	private $version;
	private $filesystem;

	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;
	}

	public function conditional_includes() {
		$screen = get_current_screen();

		if ( ! $screen ) {
			return;
		}

		switch ( $screen->id ) {
			case 'options-permalink':
				include __DIR__ . '/class-tapgoods-admin-permalinks.php';
				break;
		}
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles( $hook ) {
		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/tapgoods-admin.css', array(), $this->version, 'all' );

		// only enqueue these styles if on our settings pages
		if ( 'toplevel_page_tapgoods' === $hook ) {
			$bootstrap_version = file_exists( TAPGOODS_PLUGIN_PATH . 'assets/css/tg-bootstrap.css' ) 
				? filemtime( TAPGOODS_PLUGIN_PATH . 'assets/css/tg-bootstrap.css' ) 
				: '1.0';

				wp_enqueue_style( 
				$this->plugin_name . '-bootstrap', 
				TAPGOODS_PLUGIN_URL . 'assets/css/tg-bootstrap.css', 
				array(), 
				$bootstrap_version 
			);

			wp_enqueue_style( 
				$this->plugin_name . '-font-heebo', 
				'https://fonts.googleapis.com/css2?family=Heebo:wght@400;700&display=swap', 
				array(), 
				gmdate( 'YmdHis' )
			);
						
			wp_enqueue_style( 'wp-codemirror' );
		}
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts( $hook ) {
		if ( 'toplevel_page_tapgoods' === $hook ) {

			wp_enqueue_script( $this->plugin_name . '-admin', plugin_dir_url( __FILE__ ) . 'js/tapgoods-admin.js', array( 'jquery', $this->plugin_name . '-bootstrap' ), $this->version, false );
			wp_localize_script(
				$this->plugin_name . '-admin',
				'tg_ajax',
				array(
					'ajaxurl' => admin_url( 'admin-ajax.php' ),
				)
			);

			wp_enqueue_script( 
				$this->plugin_name . '-bootstrap', 
				TAPGOODS_PLUGIN_URL . 'assets/js/bootstrap.bundle.min.js', 
				array( 'jquery' ), 
				'5.3.2', 
				true 
			);
			

			// codemirror for custom css
			wp_enqueue_script( 'wp-theme-plugin-editor' );

			// codemirror settings being passed to javascript
			$type            = array(
				'type'      => 'text/css',
				'darkTheme' => 'true',
			);
			$readonly        = array( 'codemirror' => [ 'readOnly' => 'nocursor' ] );
			$editor_settings = wp_enqueue_code_editor( $type );
			$viewer_settings = wp_enqueue_code_editor( array_merge( $type + $readonly ) );
			wp_localize_script( 'jquery', 'tg_editor_settings', $editor_settings );
			wp_localize_script( 'jquery', 'tg_viewer_settings', $viewer_settings );

		}
	}

	/**
	 * Ajax function to encrypt and save API key
	 *
	 * @return void
	 */
	public static function tapgrein_update_connection() {

		check_ajax_referer( 'save', '_tgnonce_connection' );
		// if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
		//     die();
		// }
	
		// Delete all the items
		// $posts = get_posts([
		// 	'post_type'      => 'tg_inventory',
		// 	'numberposts'    => -1,
		// 	'post_status'    => 'any',
		// ]);
	
		// foreach ($posts as $post) {
		// 	wp_delete_post($post->ID, true); // true to delete forever
		// }
	
		// // Delete all the taxonomies: tg_location, tg_tags, tg_category. 
		// $taxonomies = ['tg_location', 'tg_tags', 'tg_category'];
		// foreach ($taxonomies as $taxonomy) {
		// 	$terms = get_terms([
		// 		'taxonomy'   => $taxonomy,
		// 		'hide_empty' => false,
		// 	]);
	
		// 	foreach ($terms as $term) {
		// 		wp_delete_term($term->term_id, $taxonomy);
		// 	}
		// }
	
		// Connection to the API
		$api_key = '';
		if ( isset( $_POST['tapgoods_api_key'] ) ) {
			$encryption        = new Tapgoods_Encryption();
			$submitted_api_key = sanitize_text_field( wp_unslash( $_POST['tapgoods_api_key'] ) );

		//	error_log('Captured API Key: ' . $submitted_api_key);
			$api_key           = $encryption->tapgrein_encrypt( $submitted_api_key );
		}
	
		$success = update_option( 'tg_key', $api_key );
	
		$client = Tapgoods_Connection::get_instance();
	
		try {
			// setting the second param to true will cause this to fail (for testing).
			$response = $client->test_connection( $submitted_api_key );
		} catch ( Error $e ) {
			self::connection_failed();
		}
	
		if ( false === $response || is_wp_error( $response ) ) {
			self::connection_failed();
		}
	
		if ( $success ) {
			update_option( 'tg_api_connected', true );
			$notice = Tapgoods_Admin::tapgrein_admin_notice( __( 'Company Key Updated.', 'tapgoods' ), [], false );
			wp_send_json_success( $notice );
		}
	
		die();
	}
	

	private static function connection_failed() {
		tapgrein_write_log( 'test_connection failed' );
		update_option( 'tg_api_connected', false );
		$args = array(
			'type' => 'error',
		);
		$env1 = ( defined( 'TG_ENV' ) ) ? TG_ENV : tapgrein_getenv_docker( 'tg_env', 'tapgoods.com' );

		$notice = Tapgoods_Admin::tapgrein_admin_notice( 
			// translators: %s is replaced with the environment name (e.g., 'production', 'staging').
			sprintf( __( 'Unable to Connect, %s. Make sure your API Key is entered correctly.', 'tapgoods' ), $env1 ), 
			$args, 
			false 
		);

		wp_send_json_error( $notice );
		die();
	}

	public static function tapgrein_api_sync() {
		// check_ajax_referer( 'save', '_tgnonce_connection' );

		$client = Tapgoods_Connection::get_instance();

		// This handler is registered on both wp_ajax_ and wp_ajax_nopriv_ for
		// tapgrein_api_sync, and that action has no nonce (WPB-176), so the
		// unauthenticated branch is reachable by anyone and not only by our own
		// cron self-ping. The label therefore states just what is known, the
		// endpoint and the auth state, instead of claiming the caller was cron.
		// The five-minute self-ping is the expected source; an unexpected volume
		// of ajax_sync_unauth runs is itself a finding.
		$trigger = ( is_user_logged_in() ) ? 'admin_ajax_sync' : 'ajax_sync_unauth';

		$response = $client->sync_from_api( $trigger );

		// tapgrein_write_log( $response );
		if ( true === $response['success'] ) {
			wp_send_json_success( $response['message'] );
		} else {
			wp_send_json_error( $response['message'] );
		}
		die();
	}

	/**
	 * Stream the sync activity log file as a download.
	 *
	 * Administrators only, and nonce-protected: the log is not reachable over HTTP
	 * by design, so this handler is the supported way to get it off the site (see
	 * admin/partials/tapgoods-sync-log.php for the link).
	 *
	 * @return void
	 */
	public static function tapgrein_download_sync_log() {

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to download this file.', 'tapgoods' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( 'tapgrein_sync_log' );

		$log      = Tapgoods_Sync_Log::get_instance();
		$contents = $log->read_all();

		if ( false === $contents ) {
			wp_die( esc_html__( 'No sync log has been written yet.', 'tapgoods' ), '', array( 'response' => 404 ) );
		}

		$filename = 'tapgoods-sync-' . gmdate( 'Ymd-His' ) . '.log';

		nocache_headers();
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . strlen( $contents ) );

		echo $contents; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- plain-text file download, not HTML.
		exit;
	}

	/**
	 * AJAX handler to load location details
	 */
	public function load_location_details() {
		// Verify nonce for security
		if (!wp_verify_nonce($_POST['nonce'] ?? '', 'tapgrein_sync_nonce')) {
			wp_send_json_error('Invalid nonce');
			return;
		}

		$location_id = sanitize_text_field($_POST['location_id'] ?? '');
		
		if (empty($location_id)) {
			wp_send_json_error('No location ID provided');
			return;
		}

		// Get location data from database
		$location_data = get_option('tg_location_' . $location_id);
		$location_data = maybe_unserialize($location_data);

		if (!$location_data) {
			wp_send_json_error('Location not found');
			return;
		}

		// Get default location for comparison
		$default_location = get_option('tapgreino_default_location');
		$is_default = ($default_location == $location_id);

		// Prepare response data
		$response_data = array(
			'location_id' => $location_id,
			'location_data' => $location_data,
			'is_default' => $is_default,
			'html' => $this->render_location_details_html($location_data, $location_id, $is_default)
		);

		wp_send_json_success($response_data);
		die();
	}

	/**
	 * Render location details HTML
	 */
	private function render_location_details_html($location_data, $location_id, $is_default) {
		ob_start();
		?>
		<h2 class="mb-4 pt-4 mt-5">Location Details</h2>
		
		<?php if ($is_default): ?>
			<p id="default_message">This is the current default location.</p>
		<?php endif; ?>

		<ul>
			<?php foreach ($location_data as $key => $value): ?>
				<li><strong><?php echo esc_html($key); ?>:</strong> 
					<?php 
					if (is_array($value)) {
						echo esc_html(json_encode($value));
					} else {
						echo esc_html((string)$value);
					}
					?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
		return ob_get_clean();
	}

	public function tg_save_advanced() {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		if ( ! isset( $_POST['_tgnonce_advanced'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_tgnonce_advanced'] ) ), 'save' ) ) {
			return false;
		}

		//Tapgoods_Helpers::tgqm( 'tg_save_advanced' );
		//Tapgoods_Helpers::tgqm( '$_REQUEST:' );
		//Tapgoods_Helpers::tgqm( $_REQUEST );

		//Tapgoods_Helpers::tgqm( '$_POST:' );
		//Tapgoods_Helpers::tgqm( $_POST );
	}

	public function tapgrein_save_dev() {

		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		if ( ! isset( $_POST['_tgnonce_dev'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_tgnonce_dev'] ) ), 'save' ) ) {
			return false;
		}

		//Tapgoods_Helpers::tgqm( 'tapgrein_save_dev' );
		//Tapgoods_Helpers::tgqm( '$_REQUEST:' );
		//Tapgoods_Helpers::tgqm( $_REQUEST );

		//Tapgoods_Helpers::tgqm( '$_POST:' );
		//Tapgoods_Helpers::tgqm( $_POST );
	}

	public function tapgrein_save_styles( $input_submit ) {
		// exit if we're not handling a post request.
		if ( empty( $_POST ) ) {
			return false;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		$action     = 'save';
		$nonce_name = '_tgnonce_css';

		if ( isset( $_REQUEST[ $nonce_name ] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST[ $nonce_name ] ) ), $action ) ) {

			// Allow saving the file even if the content is empty
			$custom_css = ( isset( $_REQUEST['tg-tapgrein_custom-css'] ) ) ? sanitize_textarea_field( wp_unslash( $_REQUEST['tg-tapgrein_custom-css'] ) ) : '';
		
			// Now we save even if the content is empty
			$success = Tapgoods_Filesystem::put_file( $input_submit, $custom_css, TAPGOODS_PLUGIN_PATH . '/public/css/tapgoods-custom.css' , $action, $nonce_name );
		
			return $success;
		}
		
	}

	public function taxonomy_intercept() {
		$screen = get_current_screen();
		if ( 'edit-tg_category' !== $screen->id || 'edit-tg_tags' !== $screen->id ) {
			return;
		}
		require_once TAPGOODS_PLUGIN_PATH . '/includes/tg_edit-tags.php';
	}

	public function tax_args_filter( $args, $taxonomy ) {
		return $args;
	}

	public function tapgrein_admin_menu() {
		$page_title = 'TapGoods';
		$menu_title = 'TapGoods';
		$capability = 'manage_options';
		$menu_slug  = $this->plugin_name;
		$function   = array( $this, 'tapgrein_admin_page' );
		$icon       = TAPGOODS_PLUGIN_URL . 'assets/img/tg-icon.png';
		$icon       = '';
		add_menu_page( $page_title, $menu_title, $capability, $menu_slug, $function, $icon, 65 );

		add_submenu_page( $this->plugin_name, $page_title . ' Connection Settings', 'Connection', $capability, $this->plugin_name, $function, 1 );
		// add_submenu_page( $this->plugin_name, $page_title . ' Styling Settings', 'Styling', $capability, $this->plugin_name . '#styling', $function, 2 );
		add_submenu_page( $this->plugin_name, $page_title . ' Shortcodes', 'Shortcodes', $capability, $this->plugin_name . '#tapgrein-shortcodes', $function, 3 );
	    add_submenu_page( $this->plugin_name, $page_title . ' Multi Location', 'Multi Location', $capability, $this->plugin_name . '#tapgrein-options', $function, 4 );
		add_submenu_page( $this->plugin_name, $page_title . ' Status', 'Status', $capability, $this->plugin_name . '#tapgrein-status', $function, 5 );
	}

	// Add a link to this plugin to the action links.
	public function add_action_links( $links ) {
		$settings_link = array(
			'<a href="' . admin_url( 'admin.php?page=' . $this->plugin_name ) . '">' . __( 'Settings', 'tapgoods') . '</a>',
		);
		return array_merge( $settings_link, $links );
	}

	// Render the admin page
	public function tapgrein_admin_page() {
		include_once 'partials/tapgoods-admin-page.php';
	}

	// Used to print admin notices
	public static function tapgrein_admin_notice( string $message, $args = [], $output = true ) {

		$args = array_merge(
			array(
				'type'               => 'success', // Available types: error, success, warning, info.
				'dismissible'        => true,
				'additional_classes' => array( 'inline', 'notice-alt' ),
				'attributes'         => array( 'data-slug' => 'plugin-slug' ),
			),
			$args
		);

		// Buffer the output so we can return it wherever its needed
		if ( ! $output ) {
			ob_start();
		}
		wp_admin_notice( $message, $args );
		if ( ! $output ) {
			$notice = ob_get_contents();
			ob_end_clean();
			return $notice;
		}
	}
}
