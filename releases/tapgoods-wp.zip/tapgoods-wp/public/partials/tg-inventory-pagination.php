<?php

// moved into tg-inventory-grid for query paged context
