<?php
/**
 * Tapgoods Core Functions
 *
 * Core functions available on both the front-end and admin.
 *
 * @package Tapgoods\Functions
 * @version 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Include core functions (available in both admin and frontend).

/**
 * Most slugs any one storefront filter may carry.
 *
 * Enforced in tapgrein_sanitize_slug_list(), which every path feeding a
 * tax_query goes through: the shortcode attribute, ?tags= / ?category=, and the
 * logged-out AJAX search. Without it, ?tags=a,b,c... or a POST to the nopriv
 * tg_search_grid action became an unbounded IN() list.
 */
if ( ! defined( 'TAPGOODS_MAX_SLUG_FILTER' ) ) {
	define( 'TAPGOODS_MAX_SLUG_FILTER', 20 );
}

/**
 * Define a constant if it is not already defined.
 *
 * @since 0.1.0
 * @param string $name  Constant name.
 * @param mixed  $value Value.
 */
function tapgrein_maybe_define_constant( $name, $value ) {
	if ( ! defined( $name ) ) {
		define( $name, $value );
	}
}

/**
 * Get permalink settings for things like products and taxonomies.
 *
 * Permalink settings are stored to the option instead of
 * being blank and inheritting from the locale. This speeds up page loading
 * times by negating the need to switch locales on each page load.
 *
 * This is inline with WP core behavior which does not localize slugs.
 *
 * @since  0.1.0
 * @return array
 */
function tapgrein_get_permalink_structure() {
	$tg_permalinks = get_option( 'tapgreino_permalinks', array() );

	$permalinks = wp_parse_args(
		array_filter( $tg_permalinks ),
		array(
			'tg_inventory_base'      => _x( 'products', 'permalink', 'tapgoods' ),
			'tg_category_base'       => _x( 'categories', 'permalink', 'tapgoods' ),
			'tg_tag_base'            => _x( 'tags', 'permalink', 'tapgoods' ),
			'use_verbose_page_rules' => 0,
		)
	);

	if ( $tg_permalinks !== $permalinks ) {
		Tapgoods_Helpers::tgqm( 'get permalinks updating: ' );
		Tapgoods_Helpers::tgqm( $tg_permalinks );
		Tapgoods_Helpers::tgqm( $permalinks );
		update_option( 'tapgreino_permalinks', $permalinks );
	}

	$permalinks['tg_inventory_rewrite_slug'] = untrailingslashit( $permalinks['tg_inventory_base'] );
	$permalinks['tg_category_rewrite_slug']  = untrailingslashit( $permalinks['tg_category_base'] );
	$permalinks['tg_tags_rewrite_slug']      = untrailingslashit( $permalinks['tg_tag_base'] );

	return $permalinks;
}

function tapgrein_fix_inventory_rewrite( $rules ) {
	global $wp_rewrite;
	$permalinks = tapgrein_get_permalink_structure();

	Tapgoods_Helpers::tgqm( $permalinks );

	// If the %tg_category% is used in the inventory permalink we need to fix some things
	if ( preg_match( '`/(.+)(/%tg_category%)`', $permalinks['tg_inventory_rewrite_slug'], $matches ) ) {

		$newrules = array();
		// if the category base is the same as the inventory base add this rule so that category perlalinks don't break
		if ( $matches[1] === $permalinks['tg_category_base'] ) {
			$newrules[] = array( '`' . $matches[1] . '/([^/]+)/?$`' => 'index.php?tg_category=$matches[1]' );
			Tapgoods_Helpers::tgqm( 'Adding rules: ' );
			Tapgoods_Helpers::tgqm( $newrules );
		}
		Tapgoods_Helpers::tgqm( 'Matches' );
		Tapgoods_Helpers::tgqm( $matches );
		Tapgoods_Helpers::tgqm( 'Rules' );
		Tapgoods_Helpers::tgqm( $rules );

		foreach ( $rules as $rule => $rewrite ) {

			if ( preg_match( '`^' . preg_quote( $matches[1], '`' ) . '/\(`', $rule ) && preg_match( '/^(index\.php\?tg_category)(?!(.*inventory))/', $rewrite ) ) {
				Tapgoods_Helpers::tgqm( 'removing rule:' );
				Tapgoods_Helpers::tgqm( $rule );
				Tapgoods_Helpers::tgqm( $rewrite );
				unset( $rules[ $rule ] );
			}
		}
		$rules = array_merge( $newrules, $rules );
	}

	Tapgoods_Helpers::tgqm( 'Updated Rules' );
	Tapgoods_Helpers::tgqm( $rules );

	if ( ! $permalinks['use_verbose_page_rules'] ) {
		return $rules;
	}

	$new = array();
	return $rules;
}
add_filter( 'rewrite_rules_array', 'tapgrein_fix_inventory_rewrite' );

function tapgrein_empty_cart_rewrite() {
	add_rewrite_tag( '%empty-cart%', '([^&]+)' );
	add_rewrite_rule( '^empty-cart/([^/]*)/?', 'index.php?empty-cart=$matches[1]', 'top' );
}
add_filter( 'init', 'tapgrein_empty_cart_rewrite', 10, 0 );

function tapgrein_get_product_dimensions( $product_id ) {

	$dimensions = array();

	$height = tapgrein_get_product_height( $product_id );
	$length = tapgrein_get_product_length( $product_id );
	$width  = tapgrein_get_product_width( $product_id );
	$weight = tapgrein_get_product_weight( $product_id );

	if ( $height ) {
		$dimensions['Height'] = $height;
	}

	if ( $length ) {
		$dimensions['Length'] = $length;
	}

	if ( $width ) {
		$dimensions['Width'] = $width;
	}

	if ( $weight ) {
		$dimensions['Weight'] = $weight;
	}

	return $dimensions;
}

function tapgrein_get_product_height( $product_id ) {

	$h_feet = get_post_meta( $product_id, 'tg_heightFt', true );
	$h_inch = get_post_meta( $product_id, 'tg_height', true );

	if ( ( '' === $h_feet || false === $h_feet ) && ( '' === $h_inch || false === $h_inch ) ) {
		return false;
	}

	$h_string  = ( '' !== $h_feet && false !== $h_feet ) ? $h_feet . "' " : '';
	$h_string .= ( '' !== $h_inch && false !== $h_inch ) ? $h_inch . '"' : '0"';

	return $h_string;
}

function tapgrein_get_product_length( $product_id ) {
	$l_feet = get_post_meta( $product_id, 'tg_lengthFt', true );
	$l_inch = get_post_meta( $product_id, 'tg_length', true );

	if ( ( '' === $l_feet || false === $l_feet ) && ( '' === $l_inch || false === $l_inch ) ) {
		return false;
	}

	$l_string  = ( '' !== $l_feet && false !== $l_feet ) ? $l_feet . "' " : '';
	$l_string .= ( '' !== $l_inch && false !== $l_inch ) ? $l_inch . '"' : '0"';

	return $l_string;
}

function tapgrein_get_product_width( $product_id ) {
	$w_feet = get_post_meta( $product_id, 'tg_widthFt', true );
	$w_inch = get_post_meta( $product_id, 'tg_width', true );

	if ( ( '' === $w_feet || false === $w_feet ) && ( '' === $w_inch || false === $w_inch ) ) {
		return false;
	}

	$w_string  = ( '' !== $w_feet && false !== $w_feet ) ? $w_feet . "' " : '';
	$w_string .= ( '' !== $w_inch && false !== $w_inch ) ? $w_inch . '"' : '0"';

	return $w_string;
}

function tapgrein_get_product_weight( $product_id ) {
	$weight = get_post_meta( $product_id, 'tg_weight', true );

	$weight_string = ( '' !== $weight && false !== $weight ) ? $weight . ' lbs' : false;
	return $weight_string;
}

function tapgrein_write_log( $data ) {
	if ( true === WP_DEBUG && true === WP_DEBUG_LOG ) {
		if ( is_array( $data ) || is_object( $data ) ) {
//			error_log( 'tgwpdev: ' . print_r( $data, true ) );
		} else {
			ob_start();
//			var_dump( $data );
			$data = ob_get_clean();
//			error_log( 'tgwpdev: ' . $data );
		}
	}
}


function tapgrein_parse_request( $wp ) {

	// tapgrein_write_log( $wp );

	Tapgoods_Helpers::tgqm( $wp );

	// Check if the request is looking for a TapGoods Category term
	if ( count( $wp->query_vars ) === 1 && array_key_exists( 'tg_category', $wp->query_vars ) ) {
		Tapgoods_Helpers::tgqm( 'tg_category pre query' );

		// Do a term query before the main query to see if the term is found
		$slug      = $wp->query_vars['tg_category'];
		$args      = array(
			'taxonomy' => array( 'tg_category', 'tg_tags' ),
			'slug'     => $slug,
			'count'    => 1,
			'hide_empty' => false,
		);
		$pre_query = get_terms( $args );
		Tapgoods_Helpers::tgqm( $args );
		Tapgoods_Helpers::tgqm( $pre_query );

		// If the term is found hook tapgrein_term_template_redirect to ensure we get to the term permalink
		if ( count( $pre_query ) !== 0 ) {
			add_action( 'template_redirect', 'tapgrein_term_template_redirect' );
			return;
		}

		// If the term isn't found, update the query_vars to search Tapgoods Inventory, pages, or posts and hook template redirect for the permalink
		$wp->query_vars = array(
			'post_type' => array( 'tg_inventory', 'page', 'post' ),
			'name'      => $slug,
		);
		add_action( 'template_redirect', 'tapgrein_template_redirect' );
		return;
	}
}

function tapgrein_custom_query_vars( $vars ) {
	$vars[] = 'empty-cart';
	$vars[] = 'set-location';
	$vars[] = 'active-filters';
	$vars[] = 'category';
	$vars[] = 'tags';
	// tapgrein_write_log( $vars );
	return $vars;
}
add_filter('query_vars', 'tapgrein_custom_query_vars');

function tapgrein_empty_cart( $wp ) {

	$empty = get_query_var( 'empty-cart', false );
	if ( isset( $_GET['empty-cart'] ) ) {
		$empty = sanitize_text_field( wp_unslash( $_GET['empty-cart'] ) ); // phpcs:ignore
	}
	if ( $empty ) {
		$domain = wp_parse_url( get_site_url(), PHP_URL_HOST );
		setcookie( 'tg_has_items', '0', 0, '/', $domain );
	}
}

/**
 * Hooked when a tg_category query is modified to check tg_inventory, Pages and Posts
 * Checks the parsed query for a permalink and redirects to the permalink if different
 */
function tapgrein_template_redirect() {
	if ( ! is_singular( 'tg_inventory' ) ) {
		return;
	}

	global $wp;
	$wp->parse_request();
	$current_url = trim( home_url( $wp->request ), '/' );
	$redirect    = get_permalink();
	$surl        = trim( $redirect, '/' );

	if ( $current_url !== $surl ) {
		wp_safe_redirect( $redirect, 301 );
		exit;
	}
}

function tapgrein_term_template_redirect() {

	// Load wp_query to get the queried object (term) ID to get the permalink, getting permalink by term slug from $wp is unreliable
	global $wp_query;
	if ( ! $wp_query->is_tax() ) {
		return;
	}

	// Load $wp to check the request URL against the term permalink
	global $wp;
	$wp->parse_request();
	$current_url = trim( home_url( $wp->request ), '/' );

	// Get the term link and check for errors
	$redirect = get_term_link( $wp_query->queried_object->term_id );
	if ( is_wp_error( $redirect ) ) {
		return; // Stop execution if there is an error
	}

	$surl = trim( $redirect, '/' );

	// If the current url isn't the permalink redirect to the permalink
	if ( $current_url !== $surl ) {
		wp_safe_redirect( $redirect, 301 );
		exit;
	}
}


function tapgrein_get_prices( $id = false ) {
	if ( false === $id ) {
		return false;
	}

	$type   = get_post_meta( $id, 'tg_productType', true );
	$prices = array();

	switch ( $type ) {
		case 'addons':
			$prices[] = array( 'each' => get_post_meta( $id, 'tg_pricing', true ) );
			// Tapgoods_Helpers::tgdd( $prices );
			break;
		default:
			$prices[] = array( 'hour' => get_post_meta( $id, 'tg_hourlyPrice', true ) );
			$prices[] = array( 'half day' => get_post_meta( $id, 'tg_halfDayPrice', true ) );
			$prices[] = array( 'day' => get_post_meta( $id, 'tg_dailyPrice', true ) );
			$prices[] = array( 'week' => get_post_meta( $id, 'tg_weeklyPrice', true ) );
			$prices[] = array( 'month' => get_post_meta( $id, 'tg_monthlyPrice', true ) );

			$flat = get_post_meta( $id, 'tg_flatPrices', true );
			if ( is_array( $flat ) ) {
				foreach ( $flat as $price ) {
					$prices[] = array( $price['name'] => $price['amount'] );
				}
			}
			break;
	}
	//Tapgoods_Helpers::tgdd( $prices );

	$prices_count = count( $prices );
	for ( $i = 0; $i < $prices_count; $i++ ) {
		if ( false === current( $prices[ $i ] ) || '' === current( $prices [ $i ] ) ) {
			unset( $prices[ $i ] );
		}
	}
	return $prices;
}

function tapgrein_get_single_display_price( $id ) {
	$prices = tapgrein_get_prices( $id );
	if ( is_array( $prices ) ) {
		$price = reset( $prices );
		if ( false == $price ) {
			return 'Pricing Unavailable';
		}
		$price_string = '$' . current( $price ) . ' / ' . array_key_first( $price );
		return $price_string;
	}
}

function tapgrein_get_all_categories() {

	$args = apply_filters(
		'tapgrein_get_all_category_args',
		array(
			'taxonomy'   => 'tg_category',
			'hide_empty' => false,
			'number'     => -1,
		)
	);

	$categories = get_terms( $args );
	return $categories;
}

function tapgrein_get_subcategories( $term ) {
	$term = get_term( $term );

	if ( ! term_exists( $term ) ) {
		return false;
	}

	$tg_subs = get_term_meta( $term, 'sfSubCategories', true );
	$args = array();

}

function tapgrein_get_locations() {
	$args = array(
		'taxonomy'   => 'tg_location',
		'hide_empty' => false,
	);

	$locations = get_terms( $args );
	return $locations;
}

function tapgrein_location_styles() {
    // Obtener el location_id dinámicamente, por ejemplo, desde una cookie o configuración
    $location_id = isset($_COOKIE['tg_location_id']) ? sanitize_text_field( wp_unslash( $_COOKIE['tg_location_id'] ) ) : get_option('tapgreino_default_location');

    // Registrar un log si no se encontró el location_id
    if ( !$location_id ) {
        tapgrein_write_log('No location_id found. Skipping style generation.');
        return '';
    }

    // Obtener las configuraciones de ubicación desde la base de datos
    $location_settings = get_option( 'tg_location_settings', false );

    if ( false === $location_settings || ! isset( $location_settings[$location_id] ) ) {
        tapgrein_write_log( "TG styles: no location settings found for location ID $location_id" );
        return '';
    }

    // Obtener configuraciones de storefront para el location_id especificado
    $sf_settings = $location_settings[$location_id];
    $button_style    = $sf_settings['buttonStyle'] ?? 'default';
    $primary_color   = $sf_settings['primaryColor'] ?? '#527390';
    $light_font      = $sf_settings['lightFontColor'] ?? '#ffffff';
    $light_secondary = $sf_settings['lightSecondaryColor'] ?? '#E5E8E9';
    $dark_font       = $sf_settings['darkFontColor'] ?? '#000000';
    $dark_secondary  = $sf_settings['darkSecondaryColor'] ?? '#9c9c9c';

    // Log the retrieved settings for debugging
    tapgrein_write_log("Generating styles for Location ID: $location_id");
    tapgrein_write_log("Primary Color: $primary_color, Button Style: $button_style");

    // Generate CSS using :root for global variables
	ob_start(); // Start output buffering
    ?>
    :root {
        --tg-color-primary: <?php echo esc_html($primary_color); ?>;
        --tg-light-font: <?php echo esc_html($light_font); ?>;
        --tg-dark-font: <?php echo esc_html($dark_font); ?>;
        --tg-light-secondary: <?php echo esc_html($light_secondary); ?>;
        --tg-dark-secondary: <?php echo esc_html($dark_secondary); ?>;
        <?php if ('rounded' === $button_style) : ?>
            --tg-button-border: 18px;
        <?php else : ?>
            --tg-button-border: 2px;
        <?php endif; ?>
    }
    <?php
    return ob_get_clean(); // Return the generated CSS instead of printing it
}


add_action('wp_head', 'tapgrein_output_location_styles');

function tapgrein_output_location_styles() {
    // Re-enabled to ensure styles load when needed
    if (!defined('DOING_AJAX') || !DOING_AJAX) {
        echo '<style>';
        echo wp_kses_post( tapgrein_location_styles() );
        echo '</style>';
    }
}






/**
 * Categories that have at least one published item in a location.
 *
 * Bounded by design, and that is the whole point. The previous implementation
 * materialised every item id for the location ( 'posts_per_page' => -1 ) and fed
 * the entire list to get_terms( 'object_ids' => ... ), which becomes a single
 * statement carrying an IN() list of every item in the catalog. On the shop's
 * default location (~18k items) that query came back empty on the customer host,
 * so tg-filter.php rendered a category menu with nothing in it, silently, while
 * smaller locations on the same site kept working. Same failure shape as the
 * sync's killed queries in WPB-165.
 *
 * The location filter now happens in SQL, so what comes back scales with the
 * number of categories (tens) instead of the number of items (tens of
 * thousands), and term hydration is chunked so no single query grows with the
 * catalog either.
 *
 * @param string|int|null $location_id TapGoods location id, or null to resolve the current one.
 * @return WP_Term[] Terms ordered by name; empty when the location has no items.
 */
function tapgrein_get_categories( $location_id = null ) {
	// If no location is specified, try to get the current user's location
	if ( null === $location_id ) {
		$location_id = tapgrein_get_wp_location_id();
	}

	// No location to scope by: every category that actually holds items. Matches
	// the per-location branch below, and keeps the menu from listing the
	// thousands of item-named placeholder terms the API returns with no items.
	if ( empty( $location_id ) ) {
		$terms = get_terms(
			array(
				'taxonomy'   => 'tg_category',
				'hide_empty' => true,
			)
		);

		$terms = is_wp_error( $terms ) ? array() : $terms;

		return apply_filters( 'tg_shop_categories', $terms, null );
	}

	$term_ids = tapgrein_get_category_ids_for_location( $location_id );

	if ( empty( $term_ids ) ) {
		return apply_filters( 'tg_shop_categories', array(), $location_id );
	}

	// Hydrate in chunks so the IN() list stays bounded however many categories a
	// business ends up with.
	$chunk_size = class_exists( 'Tapgoods_Connection' ) ? Tapgoods_Connection::TERM_CHUNK_SIZE : 150;
	$terms      = array();

	foreach ( array_chunk( $term_ids, $chunk_size ) as $chunk ) {
		$batch = get_terms(
			array(
				'taxonomy'   => 'tg_category',
				'hide_empty' => false, // The location filter already proved each of these has items.
				'include'    => $chunk,
			)
		);

		if ( ! is_wp_error( $batch ) ) {
			$terms = array_merge( $terms, $batch );
		}
	}

	usort(
		$terms,
		function ( $a, $b ) {
			return strcasecmp( $a->name, $b->name );
		}
	);

	return apply_filters( 'tg_shop_categories', $terms, $location_id );
}

/**
 * Term ids for a taxonomy that have at least one published tg_inventory item in
 * a location.
 *
 * One query whose result set is the number of terms, not the number of items, so
 * it behaves the same on a 200-item catalog and an 18,000-item one. Kept
 * separate from tapgrein_get_categories() so the location-to-terms resolution
 * can be exercised on its own.
 *
 * Results are memoised in the object cache for five minutes. Where no persistent
 * cache exists that is per-request only, which is exactly where the query is
 * cheap anyway; hosts that do run one (and where the catalog is large enough for
 * this to matter) get the benefit.
 *
 * @param string|int $location_id TapGoods location id.
 * @param string     $taxonomy    Taxonomy to resolve. Defaults to tg_category.
 * @return int[] Term ids, empty when the location has no categorised items.
 */
function tapgrein_get_category_ids_for_location( $location_id, $taxonomy = 'tg_category' ) {
	global $wpdb;

	$cache_key = 'tg_cat_ids_' . $taxonomy . '_' . md5( (string) $location_id );
	$cached    = wp_cache_get( $cache_key, 'tapgoods' );

	if ( is_array( $cached ) ) {
		return $cached;
	}

	$ids = $wpdb->get_col(
		$wpdb->prepare(
			"SELECT DISTINCT tt.term_id
			FROM {$wpdb->term_relationships} tr
			INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
			INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
			INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = tr.object_id AND pm.meta_key = %s
			WHERE tt.taxonomy = %s
			  AND p.post_type = %s
			  AND p.post_status = %s
			  AND pm.meta_value = %s",
			'tg_locationId',
			$taxonomy,
			'tg_inventory',
			'publish',
			(string) $location_id
		)
	);

	$ids = array_map( 'intval', (array) $ids );

	wp_cache_set( $cache_key, $ids, 'tapgoods', 300 );

	return $ids;
}

function tapgrein_get_tg_location_id( $post_id = false ) {

	if ( false === $post_id ) {
		$args = array(
			'taxonomy'   => 'tg_location',
			'hide_empty' => false,
			'number'     => 1,
			'fields'     => 'ids',
		);

		$locations = get_terms( $args );
	}

	if ( false !== $post_id ) {
		$locations = get_the_terms( $post_id, 'tg_location' );
	}

	if ( count( $locations ) > 0 ) {
		$tg_id = get_term_meta( current( $locations ), 'tg_id', true );
		return $tg_id;
	}

	return false;
}

//function tapgrein_get_wp_location_id( $post_id = false ) {
    function tapgrein_get_wp_location_id() {
        // Check if the value is provided via a cookie (set by JavaScript)
        if (isset($_COOKIE['tg_user_location']) && !empty($_COOKIE['tg_user_location'])) {
            return sanitize_text_field( wp_unslash( $_COOKIE['tg_user_location'] ) );
        }
    
        // Check session value (optional)
        if (isset($_SESSION['tg_user_location']) && !empty($_SESSION['tg_user_location'])) {
            return sanitize_text_field($_SESSION['tg_user_location']);
        }
    
        // Fallback to WordPress option
        $default_location = get_option('tapgreino_default_location');
        return $default_location ?: null;
    }
    
    
    

function tapgrein_locate_template( $template = '' ) {

	if ( empty( $template ) ) {
		return null;
	}

	$tg_template    = sprintf( TAPGOODS_PLUGIN_PATH . 'public/partials/%s.php', $template );
	$theme_template = sprintf( get_stylesheet_directory() . '/tapgoods/%s.php', $template );

	$valid_tg_template    = file_exists( $tg_template );
	$valid_theme_template = file_exists( $theme_template );

	if ( $valid_theme_template ) {
		return $theme_template;
	}

	if ( $valid_tg_template ) {
		return $tg_template;
	}

	return null;
}

function tapgrein_get_sf_url($wp_location_id) {
    $location_data = get_option('tg_location_' . $wp_location_id);
    return isset($location_data['sf_url']) ? $location_data['sf_url'] : '#';
}


function tapgrein_get_sf_domain( $wp_location_id ) {
	return get_term_meta( $wp_location_id, 'tg_subdomain', true );
}

function tapgrein_get_cart_url($wp_location_id) {
    // Get location data from tg_location_{ID} option
    $location_data = get_option('tg_location_' . $wp_location_id);

    if (empty($location_data) || !isset($location_data['cart_url'])) {
   //     error_log("tg_cart_url not found for location_id: " . $wp_location_id);
        return '#'; // Fallback value if no URL
    }

    // Constructing the URL with the event parameters
    $url = $location_data['cart_url'];
    $event_start = tapgrein_get_start_date() . 'T' . tapgrein_get_start_time();
    $event_end = tapgrein_get_end_date() . 'T' . tapgrein_get_end_time();
    $params = array(
        'eventStart' => $event_start,
        'eventEnd'   => $event_end,
    );

    return add_query_arg($params, $url);
}


function tapgrein_get_sign_in_url($wp_location_id) {
    $location_data = get_option('tg_location_' . $wp_location_id);
    return isset($location_data['login_url']) ? $location_data['login_url'] : '#';
}

function tapgrein_get_sign_up_url($wp_location_id) {
    $location_data = get_option('tg_location_' . $wp_location_id);
    return isset($location_data['signup_url']) ? $location_data['signup_url'] : '#';
}


function tapgrein_get_add_to_cart_url($wp_location_id) {
    $location_data = get_option('tg_location_' . $wp_location_id);
    $url = isset($location_data['add_to_cart']) ? $location_data['add_to_cart'] : '#';
    
    // Log to verify the URL value
//    error_log("Add to Cart URL: " . $url);
    
    return $url;
}


function tapgrein_get_product_add_to_cart_url( $product_id, $params = array() ) {
    // First, try to get the user's location from cookie/localStorage
    $user_location_id = null;
    
    // Check if it comes in the parameters
    if ( isset( $params['location_id'] ) ) {
        $user_location_id = $params['location_id'];
        unset( $params['location_id'] ); // Remove to avoid passing it in the URL
    }
    // If not, check the cookie
    elseif ( isset( $_COOKIE['tg_user_location'] ) ) {
        $user_location_id = sanitize_text_field( wp_unslash( $_COOKIE['tg_user_location'] ) );
    }
    // If not, check GET parameter
    elseif ( isset( $_GET['local_storage_location'] ) ) {
        $user_location_id = sanitize_text_field( wp_unslash( $_GET['local_storage_location'] ) );
    }
    
    // If we have a user location, use it
    if ( $user_location_id ) {
        $location_id = $user_location_id;
    } else {
        // If not, get the product's location from post meta
        $location_id = get_post_meta( $product_id, 'tg_locationId', true );
        
        // If the product has no location, use the default location
        if ( ! $location_id ) {
            $location_id = get_option('tapgreino_default_location');
            if ( ! $location_id ) {
                error_log("Location not found for product_id: $product_id and no default location set.");
                return '#';
            }
        }
    }
    
    // Get the base URLs using the location_id
    $base_url = tapgrein_get_add_to_cart_url( $location_id );
    $cart_url = tapgrein_get_cart_url( $location_id );
    
    // Verify that URLs are valid
    if ( $base_url === '#' || ! $cart_url ) {
        error_log("Add to Cart URL or Cart URL not found for location_id: " . $location_id);
        return '#';
    }
    
    // Get the product's itemId and itemType
    $tg_id = get_post_meta( $product_id, 'tg_id', true );
    $type  = get_post_meta( $product_id, 'tg_productType', true );
    
    // Merge additional parameters
    $params = array_merge(
        array(
            'itemId'   => $tg_id,
            'itemType' => $type,
            'quantity' => 1,
            // 'redirectUrl' => $cart_url  // Commented out to allow external setting
        ),
        $params
    );
    
    // Add parameters to the base URL
    $url = add_query_arg( $params, $base_url );
    
    error_log("Final Add to Cart URL for location $location_id: " . $url);
    
    return $url;
}



function tapgrein_date_format() {
	return 'Y-m-d';
}

function tapgrein_time_format() {
	return 'H:i';
}

function tapgrein_get_page_id( $page ) {
	$page_id = get_option( $page, false );
	return $page_id;
}

/**
 * Does this content hold an [tapgoods-inventory] that shows the whole catalog?
 *
 * "Whole catalog" means no category and no tags attribute. A page built as
 * [tapgoods-inventory category="tables"] is a curated landing page, not the
 * shop: sending a tag there gives the visitor category AND tag, which for most
 * pairs is an empty grid -- the exact symptom WPB-166 is about. So such a page
 * must never be chosen as the redirect target.
 *
 * Parsed with the shortcode regex rather than by string matching, so attribute
 * order, quoting style and whitespace do not matter. The regex's trailing
 * (?![\w-]) is what keeps [tapgoods-inventory-grid] out.
 *
 * @param string $content Post content.
 * @return bool
 */
function tapgrein_content_has_unscoped_inventory( $content ) {
	$content = (string) $content;

	if ( false === strpos( $content, '[tapgoods-inventory' ) ) {
		return false;
	}

	$pattern = get_shortcode_regex( array( 'tapgoods-inventory' ) );

	if ( ! preg_match_all( '/' . $pattern . '/', $content, $matches, PREG_SET_ORDER ) ) {
		return false;
	}

	foreach ( $matches as $shortcode ) {
		// Escaped as [[tapgoods-inventory]], which renders as literal text in a
		// documentation page and must not count. The escape is the doubled
		// bracket pair, groups 1 and 6 -- NOT group 5, which is the ENCLOSED
		// CONTENT of [tapgoods-inventory]...[/tapgoods-inventory]. Testing
		// group 5 got both cases backwards: it counted escaped text as a shop
		// page and skipped a real enclosing one.
		if ( '[' === $shortcode[1] && ']' === $shortcode[6] ) {
			continue;
		}

		// shortcode_parse_atts() answers the empty STRING, not an array, for a
		// shortcode with no attributes at all -- which is the unscoped case.
		$atts = (array) shortcode_parse_atts( isset( $shortcode[3] ) ? $shortcode[3] : '' );

		if ( empty( $atts['category'] ) && empty( $atts['tags'] ) ) {
			return true;
		}
	}

	return false;
}

/**
 * The page that hosts the storefront grid ("the shop page").
 *
 * There is no setting for this: tapgrein_get_page_id( 'shop' ) reads an option
 * that nothing ever writes, so it answers false on every site. What actually
 * defines the shop page is the page a site builder put [tapgoods-inventory] on,
 * whatever they named it, so that is what is looked for here. Resolution order:
 *
 *  1. the tg_shop_page_id filter, for a site that wants to say so explicitly;
 *  2. the tg_shop_page_id option, same thing without code;
 *  3. the oldest published page carrying an UNSCOPED [tapgoods-inventory].
 *
 * Oldest rather than newest on purpose: a site that later adds a second grid
 * page must not silently move the shop out from under existing links.
 * Deterministic either way.
 *
 * Returns 0 when the site has no such page, including when the only pages with
 * a grid on them are scoped to a category or a tag. Callers must handle that: a
 * site can legitimately have none, and guessing /shop/ would send visitors to a
 * 404 while guessing a curated page would send them to an empty grid.
 *
 * Bounded by BOTH a batch size and a batch count, because post_content LIKE
 * cannot express "unscoped": the SQL narrows to pages that mention the
 * shortcode at all, and the attribute parsing happens in PHP over one batch at
 * a time. A single LIMIT could not do this -- a site with ten category landing
 * pages older than its shop page would run out of rows and answer "no shop
 * page" while one sat just past the cut. So it pages, and stops after
 * SHOP_PAGE_BATCHES * SHOP_PAGE_BATCH rows whatever happens: a hundred pages
 * carrying a grid shortcode is not a shape worth guessing at, and such a site
 * should set the option.
 *
 * Memoised in the object cache for five minutes, including the "none" answer,
 * so neither a site with a shop page nor one without runs this per request.
 * The cached id is re-checked against post status on read, because with a
 * persistent object cache the entry outlives the page being trashed and a stale
 * id would produce a 302 to a 404.
 *
 * @return int Page id, or 0 when no shop page can be found.
 */
function tapgrein_get_shop_page_id() {
	// Rows per query, and the most queries this will ever run. 100 candidate
	// pages is the hard ceiling; see the note above.
	$batch_size  = 20;
	$batch_limit = 5;

	// The filter and the option are the documented way for a site to say which
	// page it means. Both are checked against post status, so a workaround
	// pointing at a trashed page falls through to discovery instead of
	// redirecting visitors to a 404.
	$filtered = (int) apply_filters( 'tg_shop_page_id', 0 );

	if ( $filtered > 0 && 'publish' === get_post_status( $filtered ) ) {
		return $filtered;
	}

	$configured = (int) get_option( 'tg_shop_page_id', 0 );

	if ( $configured > 0 && 'publish' === get_post_status( $configured ) ) {
		return $configured;
	}

	$cached = wp_cache_get( 'tg_shop_page_id', 'tapgoods' );

	if ( false !== $cached ) {
		$cached = (int) $cached;

		// 0 is a real answer (no shop page) and is cached on purpose.
		if ( 0 === $cached ) {
			return 0;
		}

		if ( 'publish' === get_post_status( $cached ) ) {
			return $cached;
		}
		// Stale: the page was trashed or unpublished since. Fall through.
	}

	global $wpdb;

	// Match [tapgoods-inventory] and [tapgoods-inventory att="..."], but not
	// [tapgoods-inventory-grid] / -pagination, which render a bare grid with no
	// filters or search and are not a shop page on their own. This is only a
	// prefilter; whether a candidate is scoped is decided in PHP below.
	$closed    = '%' . $wpdb->esc_like( '[tapgoods-inventory]' ) . '%';
	$with_atts = '%' . $wpdb->esc_like( '[tapgoods-inventory ' ) . '%';

	$page_id = 0;

	for ( $batch = 0; $batch < $batch_limit; $batch++ ) {
		$candidates = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID, post_content FROM {$wpdb->posts}
				WHERE post_type = 'page'
				  AND post_status = 'publish'
				  AND ( post_content LIKE %s OR post_content LIKE %s )
				ORDER BY ID ASC
				LIMIT %d OFFSET %d",
				$closed,
				$with_atts,
				$batch_size,
				$batch * $batch_size
			)
		);

		$candidates = (array) $candidates;

		foreach ( $candidates as $candidate ) {
			if ( tapgrein_content_has_unscoped_inventory( $candidate->post_content ) ) {
				$page_id = (int) $candidate->ID;
				break 2;
			}
		}

		// Short batch: there is nothing after it to page into.
		if ( count( $candidates ) < $batch_size ) {
			break;
		}
	}

	wp_cache_set( 'tg_shop_page_id', $page_id, 'tapgoods', 300 );

	return $page_id;
}

/**
 * Forget the memoised shop page id.
 *
 * Takes no arguments on purpose: the option hooks it is attached to pass
 * different things in the first position ( add_option_* passes the option NAME,
 * update_option_* the OLD VALUE ), and anything read from there would be read
 * wrongly for one of them.
 */
function tapgrein_flush_shop_page_cache() {
	wp_cache_delete( 'tg_shop_page_id', 'tapgoods' );
}
add_action( 'add_option_tg_shop_page_id', 'tapgrein_flush_shop_page_cache' );
add_action( 'update_option_tg_shop_page_id', 'tapgrein_flush_shop_page_cache' );

/**
 * Forget the memoised shop page id when a PAGE changes.
 *
 * The post-type gate is load-bearing rather than tidiness: deleted_post,
 * trashed_post and untrashed_post fire for every post type, and a sync
 * reconcile force-deletes thousands of tg_inventory posts in a single run. An
 * ungated hook would turn that into thousands of cache deletes for an entry no
 * inventory item can affect.
 *
 * The type is read from the id rather than taken from a second hook argument,
 * because deleted_post only started passing the post object in WordPress 5.5
 * and this plugin supports older.
 *
 * @param int $post_id Post the lifecycle event is about.
 */
function tapgrein_maybe_flush_shop_page_cache( $post_id ) {
	if ( 'page' !== get_post_type( $post_id ) ) {
		return;
	}

	tapgrein_flush_shop_page_cache();
}
add_action( 'save_post_page', 'tapgrein_maybe_flush_shop_page_cache' );
add_action( 'deleted_post', 'tapgrein_maybe_flush_shop_page_cache' );
add_action( 'trashed_post', 'tapgrein_maybe_flush_shop_page_cache' );
add_action( 'untrashed_post', 'tapgrein_maybe_flush_shop_page_cache' );

/**
 * Permalink of the shop page, or '' when the site has no shop page.
 *
 * @return string
 */
function tapgrein_get_shop_url() {
	$page_id = tapgrein_get_shop_page_id();

	if ( $page_id < 1 ) {
		return '';
	}

	$permalink = get_permalink( $page_id );

	return is_string( $permalink ) ? $permalink : '';
}

/**
 * Every slug form a tg_tags term may be addressed by.
 *
 * Synced tags are stored with a 'tag-' prefix so WordPress cannot share a
 * term_id between tg_category and tg_tags (see
 * Tapgoods_Connection::tg_insert_or_update_term), and the storefront links have
 * historically carried the stripped form ( ?tags=champagne ). A term created
 * any other way has no prefix at all.
 *
 * Rather than guess which convention a given slug follows -- the old code added
 * the prefix unconditionally, so a tag whose slug genuinely lacked it could
 * never be matched -- ask the tax query for both forms.
 *
 * The extra candidate could only widen the result if a site held BOTH "x" and
 * "tag-x" as separate tg_tags terms. The sync cannot produce that pair: it
 * always prefixes and dedups on the tg_id term meta. Resolving the term first
 * would rule it out completely, at the cost of a term query on every grid
 * render, which is not worth paying for a case that cannot arise from a sync.
 *
 * @param string[]|string $slugs One slug or a list of them.
 * @return string[] Unique candidate slugs; empty when nothing usable was given.
 */
function tapgrein_tag_slug_variants( $slugs ) {
	$slugs    = is_array( $slugs ) ? $slugs : array( $slugs );
	$variants = array();

	foreach ( $slugs as $slug ) {
		$slug = trim( (string) $slug );

		if ( '' === $slug ) {
			continue;
		}

		$variants[] = $slug;

		if ( 0 === strpos( $slug, 'tag-' ) ) {
			$stripped = substr( $slug, 4 );

			// A slug of exactly "tag-" strips to nothing, and an empty candidate
			// in a tax query would stop the query narrowing anything.
			if ( '' !== $stripped ) {
				$variants[] = $stripped;
			}
		} else {
			$variants[] = 'tag-' . $slug;
		}
	}

	return array_values( array_unique( $variants ) );
}

/**
 * Strip the characters that would break out of a shortcode attribute.
 *
 * Templates build shortcode strings by concatenation ( tags="{$value}" ). The
 * values are term slugs, so anything outside a slug list is noise; removing it
 * is what keeps the concatenation safe. esc_attr() is the wrong tool there and
 * was the actual cause of WPB-166: it turns the quotes into &quot;, the
 * shortcode parser then reads the entity as part of the value, and the grid
 * looks up a term named tag-&quot;tag-champagne&quot; and renders nothing.
 *
 * Whitespace goes too, not only the quotes: inside a shortcode attribute a
 * space starts the next attribute, so a value carrying one could append
 * arbitrary attributes to the tag. Term slugs never contain spaces, and the
 * grid matches on 'field' => 'slug', so nothing legitimate is lost.
 *
 * An ALLOWLIST of what a slug list is made of, not a denylist of what is known
 * to hurt today. A denylist is only ever as good as the last sink someone
 * added; this way a new caller cannot be surprised by a byte nobody thought to
 * ban. The class is:
 *
 *   A-Z a-z 0-9 _ - , %  and every high byte \x80-\xFF
 *
 * The last two matter and are why this is not the obvious [A-Za-z0-9-]. A
 * WordPress slug for a non-latin name is percent-encoded
 * ( sanitize_title() of a Japanese name gives %e6%97%a5... ), and a visitor may
 * also arrive with the same slug as raw UTF-8. An allowlist without % and the
 * high bytes ate both, so the filter silently resolved to nothing on any
 * non-latin catalog. No /u modifier, so this works bytewise: UTF-8 sequences
 * pass through whole and invalid UTF-8 cannot make preg_replace return null.
 *
 * The list is also CAPPED. Every caller of this -- the shortcode attribute, the
 * ?tags= URL parameter and the nopriv AJAX search -- feeds a tax_query, and
 * ?tags=a,b,c...x5000 turned into an IN() list of ten thousand slugs after the
 * variants helper doubled it. Capping here rather than at each caller means a
 * new caller inherits the bound instead of having to remember it. Twenty is far
 * more tags than a storefront filter ever combines.
 *
 * Note this is NOT escaping for HTML. Callers rendering the value into markup
 * still run it through esc_attr(); what this guarantees is only that the value
 * cannot break out of the shortcode attribute it is concatenated into.
 *
 * @param string $value Raw attribute value.
 * @return string Value safe to embed in a double-quoted shortcode attribute.
 */
function tapgrein_sanitize_slug_list( $value ) {
	// Curly quotes first. They are high bytes, so the allowlist below keeps
	// them, and they are harmless there -- but a page builder that smartens
	// tags="x" into tags=“x” would otherwise leave the quotes inside the value
	// and match no slug. The rest of this file strips them for the same reason.
	$value = str_replace( array( "\xe2\x80\x9c", "\xe2\x80\x9d", "\xe2\x80\x98", "\xe2\x80\x99" ), '', (string) $value );

	$clean = preg_replace( '/[^A-Za-z0-9_%,\-\x80-\xFF]/', '', $value );

	if ( null === $clean || '' === $clean ) {
		return '';
	}

	$slugs = array();

	foreach ( explode( ',', $clean ) as $slug ) {
		if ( '' === $slug ) {
			continue;
		}

		$slugs[] = $slug;

		if ( count( $slugs ) >= TAPGOODS_MAX_SLUG_FILTER ) {
			break;
		}
	}

	return implode( ',', $slugs );
}

/**
 * The tag filter that applies to a storefront render, from one place.
 *
 * Three templates used to read ?tags= with three different rules, which is how
 * the search box and the grid ended up disagreeing about what was filtered.
 * They all call this now.
 *
 * Precedence: an explicit tags="..." attribute WINS over the URL. A page built
 * as [tapgoods-inventory tags="linens"] is curated, and a visitor appending
 * ?tags=anything must not be able to re-point it; the URL only applies where
 * the page did not say. This also matches what the grid has always done with
 * its own attribute.
 *
 * Reads the registered query var first so a tg_tags term archive (the fallback
 * path, where there is no ?tags= at all) filters itself, and falls back to
 * $_GET for a request that never reached WP_Query. ?tg_tags= is honoured only
 * as a legacy alias for links made before ?tags= existed.
 *
 * @param mixed $atts Shortcode attributes, if any.
 * @return string Comma-separated slug list, sanitised; '' when unfiltered.
 */
function tapgrein_resolve_tag_filter( $atts = array() ) {
	if ( is_array( $atts ) && ! empty( $atts['tags'] ) ) {
		return tapgrein_sanitize_slug_list( $atts['tags'] );
	}

	$sources = array(
		get_query_var( 'tags', '' ),
		get_query_var( 'tg_tags', '' ),
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		isset( $_GET['tags'] ) ? wp_unslash( $_GET['tags'] ) : '',
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		isset( $_GET['tg_tags'] ) ? wp_unslash( $_GET['tg_tags'] ) : '',
	);

	foreach ( $sources as $source ) {
		if ( ! is_scalar( $source ) ) {
			continue;
		}

		$clean = tapgrein_sanitize_slug_list( $source );

		if ( '' !== $clean ) {
			return $clean;
		}
	}

	return '';
}

/**
 * Put a stored term slug into a query string without double-encoding it.
 *
 * WordPress stores a non-latin slug already percent-encoded, and add_query_arg()
 * does not encode at all, so rawurlencode() on the way out produced
 * ?tags=%25e6%2597%25a5 and nothing matched. An ASCII slug, on the other hand,
 * is stored raw and does need encoding if it somehow holds a reserved
 * character.
 *
 * @param string $slug Term slug as stored.
 * @return string Value safe to place after "tags=".
 */
function tapgrein_query_arg_slug( $slug ) {
	$slug = (string) $slug;

	// Already percent-encoded: decoding it changes it, so pass it through.
	if ( rawurldecode( $slug ) !== $slug ) {
		return $slug;
	}

	return rawurlencode( $slug );
}

function tapgrein_get_start_date() {
    // Get the start date of the cookie, if it exists
    $start_date = isset($_COOKIE['tg-eventStart']) ? sanitize_text_field( wp_unslash( $_COOKIE['tg-eventStart'] ) ) : '';

    // If the cookie date is invalid or older than today, set the start date to today
    $today = wp_date('Y-m-d');
    if (empty($start_date) || wp_date('Y-m-d', strtotime($start_date)) < $today) {
        $start_date = $today;
    }

    return $start_date;
}


function tapgrein_get_start_time() {
	return ( isset( $_COOKIE['tg-eventStart'] ) ) ? wp_date( tapgrein_time_format(), strtotime( sanitize_text_field( wp_unslash( $_COOKIE['tg-eventStart'] ) ) ) ) : wp_date( tapgrein_time_format(), strtotime( 'tomorrow 10:00 AM' ) );
}

// function tapgrein_get_end_date() {
// 	return ( isset( $_COOKIE['tg-eventEnd'] ) ) ? wp_date( tapgrein_date_format(), strtotime( sanitize_text_field( wp_unslash( $_COOKIE['tg-eventEnd'] ) ) ) ) : wp_date( tapgrein_date_format(), strtotime( '+1 day' ) );
// }

function tapgrein_get_end_date() {
    // Get the start date
    $start_date = tapgrein_get_start_date();

    // Get the cookie expiration date, if any
    $end_date = isset($_COOKIE['tg-eventEnd']) ? sanitize_text_field( wp_unslash( $_COOKIE['tg-eventEnd'] ) ) : '';

    // If the cookie date is invalid or older than three days after the start date, set to three days after the start
    $min_end_date = wp_date('Y-m-d', strtotime($start_date . ' +3 days'));
    if (empty($end_date) || wp_date('Y-m-d', strtotime($end_date)) < $min_end_date) {
        $end_date = $min_end_date;
    }

    return $end_date;
}


function tapgrein_get_end_time() {
	return ( isset( $_COOKIE['tg-eventEnd'] ) ) ? wp_date( tapgrein_time_format(), strtotime( sanitize_text_field( wp_unslash( $_COOKIE['tg-eventEnd'] ) ) ) ) : wp_date( tapgrein_time_format(), strtotime( 'tomorrow 15:00' ) );
}

function tapgrein_get_user_agent() {
	return isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
}





// Function to enqueue a script that disables editing in the Gutenberg editor
function tapgrein_disable_gutenberg_editing() {
    global $post;
    
    // Check if the post type is 'tg_inventory' and if we are on the edit screen
    if ( isset( $post->post_type ) && $post->post_type === 'tg_inventory' && is_admin() && get_current_screen()->is_block_editor() ) {
        wp_enqueue_script(
            'disable-gutenberg-editing',
            plugins_url( 'public/js/disable-gutenberg-editing.js', dirname( __FILE__ ) ), // Mejor manejo de la URL
            array( 'wp-blocks', 'wp-dom' ),
            tapgrein_asset_version( 'public/js/disable-gutenberg-editing.js' ), // Cache-busts on file change; falls back safely if the file is ever missing
            true
        );
        
    }
}
add_action( 'admin_enqueue_scripts', 'tapgrein_disable_gutenberg_editing' );

// Function to remove the 'Quick Edit' option from the list view
function tapgrein_remove_quick_edit( $actions, $post ) {
    // Check if the post type is 'tg_inventory'
    if ( $post->post_type == 'tg_inventory' ) {
        // Remove the 'Quick Edit' option
        unset( $actions['inline hide-if-no-js'] );
    }
    return $actions;
}
add_filter( 'post_row_actions', 'tapgrein_remove_quick_edit', 10, 2 );


// Function to clean up duplicate items
function tapgrein_clean_duplicate_items() {
    // Check if the 'clean_duplicates' parameter is in the URL
    if (isset($_GET['clean_duplicates']) && $_GET['clean_duplicates'] === 'true') {
        global $wpdb;

        // Add a script to display the start status in the browser console
        add_action('admin_footer', function() {
            echo "<script>console.log('Duplicate items cleanup started...');</script>";
        });

            // Execute the query to find duplicate posts
        $duplicates = $wpdb->get_results( $wpdb->prepare(
            "SELECT MIN(p1.ID) as keep_id, p2.ID as delete_id
            FROM {$wpdb->posts} p1
            INNER JOIN {$wpdb->posts} p2 ON p1.post_title = p2.post_title 
            AND p1.ID < p2.ID
            INNER JOIN {$wpdb->postmeta} pm1 ON pm1.post_id = p1.ID AND pm1.meta_key = %s
            INNER JOIN {$wpdb->postmeta} pm2 ON pm2.post_id = p2.ID AND pm1.meta_value = pm2.meta_value
            WHERE p1.post_type = %s 
            AND p2.post_type = %s
            AND p1.post_status = %s
            GROUP BY p2.ID",
            'tg_id',       // Placeholder meta_key
            'tg_inventory', // Placeholder post_type p1
            'tg_inventory', // Placeholder post_type p2
            'publish'      // Placeholder post_status
        ) );

        // Counter for deleted posts
        $deleted_count = 0;

        // Delete the duplicate posts
        foreach ($duplicates as $dup) {
            // Permanently delete the duplicate post
            wp_delete_post($dup->delete_id, true);
            $deleted_count++;
        }

        // Add a script to display the completion status in the browser console
        add_action('admin_footer', function() use ($deleted_count) {
            echo "<script>console.log('Duplicate items cleanup completed. Total deleted: " . esc_js( $deleted_count ) . "');</script>";
        });
    }
}

// Hook to clean duplicates when the admin page loads
add_action('admin_init', 'tapgrein_clean_duplicate_items');


add_action('pre_get_posts', function($query) {
    if (!is_admin() && $query->is_main_query() && $query->is_search && isset($_GET['post_type']) && $_GET['post_type'] === 'tg_inventory') {
        
        // Make sure `tg_location_id` is in the request
        if (!empty($_GET['tg_location_id'])) {
            $location_id = sanitize_text_field( wp_unslash( $_GET['tg_location_id'] ) );
            
            // Add a meta_query relation to filter by `location_id`
            $query->set('meta_query', array(
                array(
                    'key'     => 'tg_locationId',
                    'value'   => $location_id,
                    'compare' => '=',
                ),
            ));
        }
    }
});

add_action('template_redirect', function () {
    if (isset($_GET['thankyou'])) {
        include TAPGOODS_PLUGIN_PATH . '/public/partials/tg-thankyou.php';
        exit;
    }
});


// Register the AJAX handlers for logged-in and logged-out users
add_action('wp_ajax_tg_search_grid', 'tapgrein_handle_tg_search');
add_action('wp_ajax_nopriv_tg_search_grid', 'tapgrein_handle_tg_search');

/**
 * Handles the AJAX search request for tg_inventory.
 *
 * This function receives the search term and location ID from the client,
 * queries the database for matching tg_inventory posts, and returns the
 * results in JSON format.
 */
 

 function tapgrein_handle_tg_search() {
   // error_log("TG_SEARCH_GRID tapgrein_handle_tg_search called with action: " . ($_POST['action'] ?? 'NO_ACTION') . " and data: " . print_r($_POST, true));

    $search_term = isset($_POST['s']) && $_POST['s'] !== '' ? sanitize_text_field( wp_unslash( $_POST['s'] ) ) : null;
    $location_id = isset($_POST['tg_location_id']) ? sanitize_text_field( wp_unslash( $_POST['tg_location_id'] ) ) : '';
    // Slug sanitizer, not sanitize_text_field(): that strips percent octets, so
    // a non-latin tag slug arrived empty here and the search quietly answered
    // with the whole catalog instead of the filtered set.
    $posted_tags = isset($_POST['tg_tags']) ? tapgrein_sanitize_slug_list( wp_unslash( $_POST['tg_tags'] ) ) : '';
    $tags = ('' === $posted_tags) ? [] : explode(',', $posted_tags);
    $categories = isset($_POST['tg_categories']) && !empty($_POST['tg_categories']) ? explode(',', sanitize_text_field( wp_unslash( $_POST['tg_categories'] ) ) ) : [];
    $per_page = isset($_POST['per_page_default']) ? (int) sanitize_text_field( wp_unslash( $_POST['per_page_default'] ) ) : 12;
    $paged = isset($_POST['paged']) ? (int) sanitize_text_field( wp_unslash( $_POST['paged'] ) ) : 1;
    $is_default  = isset($_POST['default']) && $_POST['default'] === 'true';
    $show_pricing = isset($_POST['show_pricing']) ? $_POST['show_pricing'] === 'true' : true;
    

    // Decode HTML entities in category names
    $categories = array_map(function($category) {
        return htmlspecialchars_decode($category);
    }, $categories);

    // Match a tag by either slug form. Adding the 'tag-' prefix unconditionally,
    // as this used to, cannot find a tag whose slug never had one. Categories
    // need no prefix at all.
    if (!empty($tags)) {
        $tags = tapgrein_tag_slug_variants($tags);
    }

    $args = [
        'post_type'      => 'tg_inventory',
        'post_status'    => 'publish',
        'posts_per_page' => $per_page,
        'paged'          => $paged,
        'orderby'        => 'title',
        'order'          => 'ASC',
        'meta_query'     => [
            [
                'key'     => 'tg_locationId',
                'value'   => $location_id,
                'compare' => '=',
            ],
        ],
        'tax_query'      => [],
    ];

    // Apply filters based on whether it's a default load or a search
    if (!$is_default && !empty($search_term)) {
        $args['s'] = $search_term;
    }

    if (!empty($categories)) {
        $args['tax_query'][] = [
            'taxonomy' => 'tg_category',
            'field'    => 'slug',
            'terms'    => $categories,
            'operator' => 'IN',
        ];
    }

    if (!empty($tags)) {
        $args['tax_query'][] = [
            'taxonomy' => 'tg_tags',
            'field'    => 'slug',
            'terms'    => $tags,
            'operator' => 'IN',
        ];
    }

    if (count($args['tax_query']) > 1) {
        $args['tax_query']['relation'] = 'AND';
    }

    $query = new WP_Query($args);

    $results = [];
    // Include row wrapper to preserve exact structure used by templates
    $row_open  = '<div class="tapgoods tapgoods-inventory row row-cols-2 row-cols-sm-2 row-cols-lg-3 g-3">';
    $row_close = '</div>';
    $items_html = '';
    $base_url = tapgrein_get_add_to_cart_url( $location_id );
    // Build current URL for proper redirect, can be overridden by POST
    $redirect_url = null;
    if ( isset($_POST['redirect_url']) && $_POST['redirect_url'] !== '' ) {
        $redirect_url = esc_url_raw( wp_unslash( $_POST['redirect_url'] ) );
    } else {
        // Fallback to current URL logic mirroring tg-inventory-grid.php
        $current_url = home_url( add_query_arg( array(), $wp->request ) );
        if ( ! empty( $_SERVER['QUERY_STRING'] ) ) {
            $query_string = isset( $_SERVER['QUERY_STRING'] ) ? sanitize_text_field( wp_unslash( $_SERVER['QUERY_STRING'] ) ) : '';
            $current_url .= '?' . $query_string;
        }
        $redirect_url = $current_url;
    }
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $result_item = [
                'title'   => get_the_title(),
                'excerpt' => wp_trim_words(get_the_content(), 15),
                'url'     => get_permalink(),
                'img_url' => get_the_post_thumbnail_url(get_the_ID(), 'medium'),
                'tg_id'   => get_post_meta(get_the_ID(), 'tg_id', true),
            ];
            
            if ($show_pricing) {
                $result_item['price'] = tapgrein_get_single_display_price(get_the_ID());
            }
            
            $results[] = $result_item;

            // Build minimal, styled item card HTML to allow client-side direct replacement of grid only
            $tg_id    = get_post_meta(get_the_ID(), 'tg_id', true);
            // Prefer imgixUrl like the template
            $pictures = get_post_meta(get_the_ID(), 'tg_pictures', true);
            $img_tag  = '';
            if (!empty($pictures) && is_array($pictures) && isset($pictures[0]['imgixUrl'])) {
                $img_tag = Tapgoods_Public::get_img_tag($pictures[0]['imgixUrl'], '254', '150');
            }
            $price    = $show_pricing ? tapgrein_get_single_display_price(get_the_ID()) : '';
            $item_url = get_permalink();
            
            // Add nprice=true parameter to URL when pricing is disabled
            if (!$show_pricing) {
                $separator = strpos($item_url, '?') !== false ? '&' : '?';
                $item_url .= $separator . 'nprice=true';
            }
            
            // Build add to cart URL using current page as redirect (like original template)
            $add_url  = tapgrein_get_product_add_to_cart_url(
                get_the_ID(),
                array('redirectUrl' => $redirect_url)
            );
            $items_html .= '<div id="tg-item-' . esc_attr($tg_id) . '" class="col item">'
                . '<div class="item-wrap">'
                . '<figure>'
                . '<a class="d-block" href="' . esc_url( $item_url ) . '">'
                . ( ! empty( $img_tag ) ? wp_kses( $img_tag, [ 'img' => [ 'src'=>true,'srcset'=>true,'sizes'=>true,'width'=>true,'height'=>true,'alt'=>true,'loading'=>true,'decoding'=>true,'class'=>true,'id'=>true ] ] ) : '' )
                . '</a>'
                . '</figure>'
                . ($show_pricing && ! empty( $price ) ? '<div class="price mb-2">' . esc_html( $price ) . '</div>' : '')
                . '<a class="d-block item-name mb-2" href="' . esc_url( $item_url ) . '"><strong>' . esc_html( get_the_title() ) . '</strong></a>'
                . '<div class="add-to-cart">'
                . '<input class="qty-input form-control round" type="text" inputmode="numeric" placeholder="Qty" value="1" id="qty-' . esc_attr( $tg_id ) . '">'
                . '<button type="button" data-target="' . esc_url( $add_url ) . '" data-item-id="' . esc_attr( $tg_id ) . '" class="add-cart btn btn-primary">' . esc_html__( 'Add', 'tapgoods' ) . '</button>'
                . '</div>'
                . '</div>'
                . '</div>';
        }
    } else {
        // No results. If a search term was provided, return a friendly message in the grid
        if (!empty($search_term)) {
            $safe_term = esc_html($search_term);
            $items_html = '<div class="col-12"><p>No results found for "' . $safe_term . '". Please try a different search.</p></div>';
        }
        // else leave empty to show an empty grid for default load with zero items
    }

    wp_reset_postdata();

    wp_send_json_success([
        'results'      => $results,
        'html'         => $row_open . $items_html . $row_close,
        'total_pages'  => $query->max_num_pages,
        'current_page' => $paged,
    ]);
}


add_action('wp_ajax_load_status_tab_content', function () {
    ob_start();

    $api_connected = get_option('tg_api_connected');
    $key_defined = defined('TAPGOODS_KEY');
    $location_settings = maybe_unserialize(get_option('tg_location_settings'));
    $reset_done = get_option('tapgreino_reset_done');

    ?>
    <div class="container">
    <!-- Status Information -->
    <h2 class="mb-4">Status Information</h2>
    <ul class="list-unstyled mb-4">
        <li class="d-flex align-items-center mb-2">
            <strong class="me-2">API Connected:</strong>
            <span class="<?php echo $api_connected ? 'text-success fw-bold' : 'text-danger fw-bold'; ?>">
                <?php echo $api_connected ? 'Yes' : 'No'; ?>
            </span>
        </li>
        <li class="d-flex align-items-center mb-2">
            <strong class="me-2">TAPGOODS_KEY Defined:</strong>
            <span class="<?php echo $key_defined ? 'text-success fw-bold' : 'text-danger fw-bold'; ?>">
                <?php echo $key_defined ? 'Yes' : 'No'; ?>
            </span>
        </li>
        <li class="d-flex align-items-center">
            <strong class="me-2">Reset Done:</strong>
            <span class="<?php echo $reset_done ? 'text-success fw-bold' : 'text-danger fw-bold'; ?>">
                <?php echo $reset_done ? 'Yes' : 'No'; ?>
            </span>
        </li>
    </ul>

    <div class="position-absolute start-0 end-0" style="height: 16px; background-color: #f0f0f1;"></div>

    <!-- Location Settings -->

    <h2 class="mb-4 pt-4 mt-5">Location Settings</h2>
    <div class="accordion" id="locationSettingsAccordion">
        <?php foreach ($location_settings as $location_id => $settings): ?>
            <div class="accordion-item mb-3">
                <h2 class="accordion-header" id="heading<?php echo esc_attr($location_id); ?>">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo esc_attr($location_id); ?>" aria-expanded="false" aria-controls="collapse<?php echo esc_attr($location_id); ?>">
                        <?php echo esc_html($location_id); ?>
                    </button>
                </h2>
                <div id="collapse<?php echo esc_attr($location_id); ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo esc_attr($location_id); ?>" data-bs-parent="#locationSettingsAccordion">
                    <div class="accordion-body">
                        <ul class="list-unstyled">
                            <?php foreach ($settings as $key => $value): ?>
                                <li class="mb-2">
                                    <strong><?php echo esc_html($key); ?>:</strong> 
                                    <span>
                                        <?php echo esc_html(is_array($value) ? json_encode($value, JSON_PRETTY_PRINT) : $value); ?>
                                    </span>
                                </li>
                                
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <hr class="my-4">
        <?php endforeach; ?>
    </div>

    <?php require dirname( __DIR__ ) . '/admin/partials/tapgoods-sync-log.php'; ?>
</div>

    <?php

    echo wp_kses_post( ob_get_clean() );
    wp_die();
});


function tapgrein_get_default_location() {
    // Check if the value is provided via AJAX
    if (isset($_POST['local_storage_location']) && !empty($_POST['local_storage_location'])) {
        // Sanitize and return the value from localStorage
        return sanitize_text_field( wp_unslash( $_POST['local_storage_location'] ) );
    }

    // Otherwise, return the value from the WordPress options
    $default_location = get_option('tapgreino_default_location');
    return $default_location ?: null;
}

add_action('wp_ajax_tapgrein_get_default_location', 'tapgrein_get_default_location_ajax');
add_action('wp_ajax_nopriv_tapgrein_get_default_location', 'tapgrein_get_default_location_ajax');

function tapgrein_get_default_location_ajax() {
    // Use the tapgrein_get_default_location function to determine the value
    $default_location = tapgrein_get_default_location();

    // Return the value as JSON
    wp_send_json_success($default_location);
    wp_die(); // Required to terminate properly
}

add_action('wp_ajax_tapgrein_set_local_storage_location', 'tapgrein_set_local_storage_location');
add_action('wp_ajax_nopriv_tapgrein_set_local_storage_location', 'tapgrein_set_local_storage_location');

function tapgrein_set_local_storage_location() {
    if (isset($_POST['local_storage_location']) && !empty($_POST['local_storage_location'])) {
        // Optionally store in a session or other server-side variable
        $_SESSION['tapgreino_default_location'] = isset($_POST['local_storage_location']) ? sanitize_text_field( wp_unslash( $_POST['local_storage_location'] ) ) : '';
        wp_send_json_success( isset($_SESSION['tapgreino_default_location']) ? sanitize_text_field( wp_unslash( $_SESSION['tapgreino_default_location'] ) ) : '' );
    } else {
        wp_send_json_error('No location provided');
    }

    wp_die();
}




add_action('wp_ajax_tapgrein_get_item_image', 'tapgrein_get_item_image');
add_action('wp_ajax_nopriv_tapgrein_get_item_image', 'tapgrein_get_item_image'); // For non-logged-in users

function tapgrein_get_item_image() {
//    error_log('AJAX call received in tapgrein_get_item_image');
//    error_log('POST Data: ' . print_r($_POST, true));

    if (!isset($_POST['item_id']) || empty($_POST['item_id'])) {
//        error_log('Item ID is missing or invalid.');
        wp_send_json_error(['message' => 'Item ID is missing or invalid.']);
        return;
    }

    $item_id = intval($_POST['item_id']);
//    error_log('Item ID: ' . $item_id);

    if ($item_id <= 0) {
//        error_log('Invalid Item ID.');
        wp_send_json_error(['message' => 'Invalid Item ID.']);
        return;
    }

    $pictures = get_post_meta($item_id, 'tg_pictures', true);
//    error_log('Pictures Meta: ' . print_r($pictures, true));

    if (!empty($pictures) && isset($pictures[0]['imgixUrl'])) {
        $img_url = $pictures[0]['imgixUrl'];
//        error_log("Image found for Item ID $item_id: $img_url");
        wp_send_json_success(['img_url' => $img_url]);
    } else {
        $placeholder_url = esc_url(plugin_dir_url(__FILE__) . 'assets/img/placeholder.png');
//        error_log("No image found for Item ID $item_id. Using placeholder: $placeholder_url");
        wp_send_json_success(['img_url' => $placeholder_url]);
    }
}

add_action('wp_ajax_tapgrein_get_image_by_item_id', 'tapgrein_get_image_by_item_id');
add_action('wp_ajax_nopriv_tapgrein_get_image_by_item_id', 'tapgrein_get_image_by_item_id');

function tapgrein_get_image_by_item_id() {
    if (!isset($_POST['item_id']) || empty($_POST['item_id'])) {
        wp_send_json_error(['message' => 'Invalid item_id provided.']);
    }

    $item_id = isset($_POST['item_id']) ? sanitize_text_field( wp_unslash( $_POST['item_id'] ) ) : '';

    global $wpdb;

    // Get the post_id from the postmeta table
    $post_id = $wpdb->get_var($wpdb->prepare(
        "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = 'tg_id' AND meta_value = %s",
        $item_id
    ));

    if (!$post_id) {
        wp_send_json_error(['message' => "No post found for item_id $item_id."]);
    }

    // Get the images from meta_key 'tg_pictures'
    $pictures = get_post_meta($post_id, 'tg_pictures', true);

    if (empty($pictures) || !is_array($pictures)) {
        wp_send_json_error(['message' => "No images found for post_id $post_id."]);
    }

    // Send the first image
    $image_url = $pictures[0]['imgixUrl'] ?? null;

    if (!$image_url) {
        wp_send_json_error(['message' => "Image URL missing for post_id $post_id."]);
    }

    wp_send_json_success(['image_url' => $image_url]);
}


function tapgrein_update_inventory_grid() {
    if (isset($_POST['category'])) {
        $category = isset($_POST['category']) ? sanitize_text_field( wp_unslash( $_POST['category'] ) ) : '';
//        error_log("AJAX received category: " . $category);

        // Generate the shortcode dynamically
        $shortcode = "[tapgoods-inventory-grid category=\"$category\"]";
//        error_log("Shortcode generated dynamically: " . $shortcode);

        echo do_shortcode($shortcode);
    } else {
 //       error_log("AJAX missing category parameter.");
        echo "Error: Missing category.";
    }
    wp_die();
}
add_action( 'wp_ajax_update_inventory_grid', 'tapgrein_update_inventory_grid' );
add_action( 'wp_ajax_nopriv_update_inventory_grid', 'tapgrein_update_inventory_grid' );

/**
 * Send a tg_tags term archive to the shop grid, filtered by that tag (WPB-166).
 *
 * A tag is reached from the "Tags" list on an item page and from
 * TapGoods > Tags > View in wp-admin. Both land on the term archive, which is
 * not a storefront: the visitor expects the shop they came from, narrowed to
 * that tag, exactly as a category click narrows it. So resolve the shop page and
 * redirect there with ?tags=<slug>.
 *
 * Three things this deliberately does:
 *
 * - It carries the term's REAL slug, not a stripped one. The consumers accept
 *   both forms (tapgrein_tag_slug_variants), so a tag whose slug never had the
 *   'tag-' prefix routes as well as a synced one.
 * - It puts the filter in the URL and nowhere else. Customer pages are cached
 *   per URL with no device or cookie variance, so a filter held in a cookie or
 *   a session would be baked into whatever the first visitor warmed.
 * - It only runs when a shop page actually exists. Guessing home_url('/shop/')
 *   -- what the old dead code here did -- sends visitors to a 404 on any site
 *   that named the page something else, which is most of them.
 *
 * 302, not 301: the target depends on which page holds [tapgoods-inventory],
 * which a site owner can change. A permanent redirect would be cached in
 * visitors' browsers and would keep pointing at a page that had moved.
 *
 * Only tg_tags is routed. Category archives are intentionally left alone; that
 * behaviour was removed for the redemption-tents issue (WP-132).
 */
function tapgrein_redirect_tag_archives() {
	if ( is_admin() || wp_doing_ajax() || is_feed() || is_robots() || is_embed() ) {
		return;
	}

	if ( ! is_tax( 'tg_tags' ) ) {
		return;
	}

	$term = get_queried_object();

	if ( ! $term instanceof WP_Term || empty( $term->slug ) ) {
		return;
	}

	$shop_url = tapgrein_get_shop_url();

	if ( '' === $shop_url ) {
		// No shop page on this site, or the only grid pages are scoped to a
		// category: fall through to tg-tag-results.php, which renders the same
		// filtered grid in place. A redirect to nothing, or to a curated page
		// that would AND its own category with this tag, is worse than the
		// archive we are on.
		return;
	}

	// Carry the rest of the query string. A tag link can arrive with campaign
	// parameters on it, and dropping them loses the attribution for every visit
	// that starts at a tag. Read $_GET rather than $_SERVER['QUERY_STRING']:
	// the latter is set by the web server, so it is absent under some SAPIs and
	// under the test runner.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$carried = wp_unslash( (array) $_GET );

	// Everything WordPress itself routes on is dropped, not just the taxonomy
	// vars. These described the archive being left, and on the page being
	// entered they mean something else entirely: /tags/x/?embed=true carried
	// through would land the visitor on the shop page's oEmbed document rather
	// than the shop. Campaign parameters and anything else unknown to WordPress
	// are not in this list and do carry through.
	$public_vars = isset( $GLOBALS['wp']->public_query_vars ) ? (array) $GLOBALS['wp']->public_query_vars : array();
	$carried     = array_diff_key( $carried, array_flip( $public_vars ) );

	// Belt and braces for the handful that matter most, in case the global is
	// not available this early on some install.
	unset( $carried['tg_tags'], $carried['taxonomy'], $carried['term'], $carried['tags'], $carried['paged'], $carried['page'], $carried['embed'], $carried['s'] );

	$query = '';

	if ( ! empty( $carried ) ) {
		$query = http_build_query( $carried, '', '&', PHP_QUERY_RFC3986 );
	}

	// The slug goes on last and unencoded by http_build_query, because a stored
	// non-latin slug is already percent-encoded.
	$query .= ( '' === $query ? '' : '&' ) . 'tags=' . tapgrein_query_arg_slug( $term->slug );

	// /tags/x/page/2/ is a real URL WordPress will serve. The grid paginates on
	// ?paged=, so map it rather than silently dropping the visitor on page one.
	$paged = (int) get_query_var( 'paged' );

	if ( $paged > 1 ) {
		$query .= '&paged=' . $paged;
	}

	$redirect_url = $shop_url . ( false === strpos( $shop_url, '?' ) ? '?' : '&' ) . $query;

	wp_safe_redirect( $redirect_url, 302 );
	exit;
}
add_action( 'template_redirect', 'tapgrein_redirect_tag_archives' );

/**
 * Fallback for a site with no shop page: render the tag's grid on the archive.
 *
 * tapgrein_redirect_tag_archives() has already run by the time template_include
 * fires, so this only ever renders when there was nowhere to redirect to.
 */
add_filter('template_include', 'tapgrein_custom_tax_template');
function tapgrein_custom_tax_template($template) {
    // Check if this is a taxonomy archive page for a custom taxonomy
    if (is_tax('tg_tags')) {
        // Define the correct custom template path
        $custom_template = TAPGREIN_PLUGIN_DIR . 'public/partials/tg-tag-results.php';

        // Check if the custom template file exists
        if (file_exists($custom_template)) {
            return $custom_template; // Return the custom template
        }
    }

    return $template; // Return the default template if conditions are not met
}

// A wp_head hook that enqueued the public script "for tag pages" used to live
// here. It could never do that: tg-tag-results.php never calls get_header(), so
// wp_head() does not run on a tag archive at all. What it did run on was every
// other page of the site, where it wrote five error_log lines per request and
// enqueued nothing. The template enqueues and prints its own script (see
// tg-tag-results.php), so removing it changes no behaviour and stops the noise.


// Ensure Yoast SEO metabox is added to tg_inventory
function tapgrein_enable_yoast_seo_for_tg_inventory() {
    // Verificar si Yoast SEO está activo antes de habilitar el soporte
    if (defined('WPSEO_VERSION')) {
        add_post_type_support('tg_inventory', 'wpseo-meta'); // Enable Yoast SEO support
    }
}
add_action('init', 'tapgrein_enable_yoast_seo_for_tg_inventory', 20);

// Ensure Yoast metabox is added to the post edit screen
function tapgrein_force_yoast_seo_metabox_on_tg_inventory() {
    // Verificar si Yoast SEO está activo antes de agregar el metabox
    if (defined('WPSEO_VERSION') && function_exists('wpseo_meta_box')) {
        add_meta_box('wpseo_meta', __('Yoast SEO', 'tapgoods'), 'wpseo_meta_box', 'tg_inventory', 'normal', 'high');
    }
}
add_action('add_meta_boxes', 'tapgrein_force_yoast_seo_metabox_on_tg_inventory');

// Ensure Yoast SEO scripts are properly enqueued
function tapgrein_enqueue_yoast_seo_assets($hook) {
    global $post;

    // Solo verificar que estamos en la página correcta
    // Yoast SEO maneja sus propios scripts automáticamente
    if ('post.php' === $hook && isset($post) && 'tg_inventory' === get_post_type($post)) {
        // Verificar si Yoast SEO está activo antes de hacer cualquier cosa
        if (defined('WPSEO_VERSION')) {
            // Yoast SEO está activo y manejará sus propios scripts
            // No necesitamos encolar scripts adicionales
        }
    }
}
add_action('admin_enqueue_scripts', 'tapgrein_enqueue_yoast_seo_assets');

// Add custom column to show parent category for tags in admin
add_filter('manage_edit-tg_tags_columns', 'tapgrein_add_parent_category_column');
function tapgrein_add_parent_category_column($columns) {
    // Add new column after the 'name' column
    $new_columns = array();
    foreach ($columns as $key => $value) {
        $new_columns[$key] = $value;
        if ($key === 'name') {
            $new_columns['parent_category'] = __('Parent Category', 'tapgoods');
        }
    }
    return $new_columns;
}

// Populate the parent category column
add_filter('manage_tg_tags_custom_column', 'tapgrein_populate_parent_category_column', 10, 3);
function tapgrein_populate_parent_category_column($content, $column_name, $term_id) {
    if ($column_name === 'parent_category') {
        $parent_category_id = get_term_meta($term_id, 'tg_parent_category', true);

        if ($parent_category_id) {
            $parent_category = get_term($parent_category_id, 'tg_category');
            if ($parent_category && !is_wp_error($parent_category)) {
                $content = esc_html($parent_category->name);
            } else {
                $content = '<span style="color: #999;">—</span>';
            }
        } else {
            $content = '<span style="color: #999;">No parent</span>';
        }
    }
    return $content;
}

// Make the parent category column sortable
add_filter('manage_edit-tg_tags_sortable_columns', 'tapgrein_make_parent_category_sortable');
function tapgrein_make_parent_category_sortable($columns) {
    $columns['parent_category'] = 'parent_category';
    return $columns;
}

// Ensure REST API compatibility for Yoast SEO
function tapgrein_enable_rest_api_for_tg_inventory($args, $post_type) {
    if ('tg_inventory' === $post_type) {
        $args['show_in_rest'] = true; // Ensure the post type supports REST API
    }
    return $args;
}
add_filter('register_post_type_args', 'tapgrein_enable_rest_api_for_tg_inventory', 10, 2);


// Register the cron event if it does not exist
function register_sync_cron() {
    if (!wp_next_scheduled('tg_auto_sync_event')) {
        wp_schedule_event(time(), 'daily', 'tg_auto_sync_event'); // Now runs every 24 hours
    }
}
add_action('wp', 'register_sync_cron');

// Add a custom interval of 24 hours
function add_custom_sync_interval($schedules) {
    $schedules['daily'] = array(
        'interval' => DAY_IN_SECONDS, // 24 hours
        'display'  => __('Every 24 Hours')
    );
    return $schedules;
}
add_filter('cron_schedules', 'add_custom_sync_interval');

// Hook to execute synchronization automatically when the event is triggered
add_action('tg_auto_sync_event', 'execute_auto_sync');

/**
 * Executes the automatic synchronization process.
 *
 * Reached two ways, which is why the trigger is a parameter: the daily
 * tg_auto_sync_event cron fires it with no arguments, and the frontend 24h
 * fallback below fires the same action passing 'frontend_fallback'. Both look
 * identical from inside sync_inventory_in_batches(), so they have to name
 * themselves for the activity log to be able to tell them apart.
 *
 * @param string $trigger Which path fired this run.
 */
function execute_auto_sync($trigger = 'cron_daily') {
    $tg_api = Tapgoods_Connection::get_instance();

    // Prefer the Action Scheduler driver: enqueue a slice (guarded, so it never
    // duplicates an in-flight chain) and let it chain the rest in the background,
    // instead of running a single bounded slice inline in the cron/frontend
    // request. Fall back to the inline slice when Action Scheduler is unavailable.
    if (class_exists('Tapgoods_Sync_Scheduler') && Tapgoods_Sync_Scheduler::is_available()) {
        Tapgoods_Sync_Scheduler::enqueue_slice();
        return;
    }

    if (method_exists($tg_api, 'sync_inventory_in_batches')) {
        $tg_api->sync_inventory_in_batches(false, $trigger);
        error_log('Auto-sync executed.');
    } else {
        error_log('Error: No valid sync function found in Tapgoods_Connection.');
    }
}

// AJAX action to manually execute synchronization when clicking the SYNC button
function execute_manual_sync() {
    $tg_api = Tapgoods_Connection::get_instance();

    // This endpoint is also registered for wp_ajax_nopriv (see below), so the run
    // is labelled by whether the caller was authenticated. The missing nonce on
    // that unauthenticated registration is tracked separately (WPB-176); it is
    // only labelled here, not fixed.
    $trigger = ( function_exists('is_user_logged_in') && is_user_logged_in() ) ? 'ajax_manual' : 'ajax_nopriv';

    // Prefer the non-blocking Action Scheduler driver: enqueue the first slice and
    // return immediately; the chain continues in the background. Fall back to an
    // inline bounded slice when Action Scheduler is unavailable.
    if (class_exists('Tapgoods_Sync_Scheduler') && Tapgoods_Sync_Scheduler::is_available()) {
        Tapgoods_Sync_Scheduler::enqueue_slice();
        // wp_send_json_success() calls wp_die(), so control never returns here.
        wp_send_json_success('Sync started; it runs in the background.');
    }

    if (method_exists($tg_api, 'sync_inventory_in_batches')) {
        $tg_api->sync_inventory_in_batches(false, $trigger);
        wp_send_json_success('Sync executed successfully.');
    } else {
        error_log('Error: No valid sync function found in Tapgoods_Connection.');
        wp_send_json_error('Sync function not found.');
    }
}

// Hook to allow manual synchronization via AJAX (without nonce validation)
add_action('wp_ajax_execute_manual_sync', 'execute_manual_sync');
add_action('wp_ajax_nopriv_execute_manual_sync', 'execute_manual_sync'); // Allows execution without authentication

// Ensure the sync cron is scheduled and trigger it on frontend visits
add_action('init', function() {
    if (!wp_next_scheduled('tg_auto_sync_event')) {
        wp_schedule_event(time(), 'daily', 'tg_auto_sync_event');
    }

    // Check if the last sync was more than 24 hours ago and execute it if necessary
    if (!is_admin()) { // Execute only on frontend visits
        $last_run = get_option('tg_last_sync_time', 0);
        if (time() - $last_run >= DAY_IN_SECONDS) { // 86400 seconds = 24 hours
            update_option('tg_last_sync_time', time());
            // Same action as the daily cron, but a different trigger: pass the name
            // so the activity log can tell a visitor-driven sync from a cron one.
            do_action('tg_auto_sync_event', 'frontend_fallback'); // Manually trigger the sync process
        }
    }
});













// Build up to 150 chars of your own “tg_description” or fallback
function tapgrein_get_default_meta_description() {
    if ( ! is_singular( 'tg_inventory' ) ) {
        return '';
    }
    global $post;
    $desc = get_post_meta( $post->ID, 'tg_description', true );
    if ( empty( $desc ) ) {
        $desc = sprintf( 'Rent %s today.', get_the_title( $post ) );
    }
    $desc = wp_strip_all_tags( $desc );
    return trim( mb_substr( $desc, 0, 150 ) );
}

// Only if Yoast is NOT active, print your fallback in <head>
add_action( 'wp_head', 'tapgrein_print_fallback_meta_description', 1 );
function tapgrein_print_fallback_meta_description() {
    // Bail if Yoast is active or not on a single inventory item
    if ( defined( 'WPSEO_VERSION' ) || ! is_singular( 'tg_inventory' ) ) {
        return;
    }
    $desc = tapgrein_get_default_meta_description();
    if ( $desc ) {
        echo '<meta name="description" content="' . esc_attr( $desc ) . "\" />\n";
    }
}


/**
 * Fix pagination issues for TapGoods Inventory Grid
 * Add this to your plugin's main file or functions.php
 */

// Fix pagination URL format and query handling
function tapgrein_fix_pagination_urls() {
    // Only run on frontend
    if (is_admin()) {
        return;
    }
    
    // Fix paged query var detection
    add_action('init', 'tapgrein_fix_paged_query_var');
    
    // Fix pagination links format
    add_filter('paginate_links', 'tapgrein_force_pagination_format');
    
    // Handle URL redirects for problematic formats
    add_action('template_redirect', 'tapgrein_redirect_pagination_urls');
    
    // Ensure paged parameter is recognized
    add_action('pre_get_posts', 'tapgrein_fix_main_query_paged');
}
add_action('wp', 'tapgrein_fix_pagination_urls');

/**
 * Fix paged query var detection
 */
function tapgrein_fix_paged_query_var() {
    global $wp;
    
    // Add 'paged' to public query vars if not already present
    if (!in_array('paged', $wp->public_query_vars)) {
        $wp->add_query_var('paged');
    }
    
    // Ensure paged parameter from URL is captured
    if (isset($_GET['paged']) && !empty($_GET['paged'])) {
        set_query_var('paged', intval($_GET['paged']));
    }
}

/**
 * Force pagination links to use ?paged=X format
 */
function tapgrein_force_pagination_format($link) {
    // Check if this is a pagination link with /page/X/ format
    if (preg_match('/\/page\/(\d+)\/?(\?.*)?$/', $link, $matches)) {
        $page_num = $matches[1];
        $query_string = isset($matches[2]) ? $matches[2] : '';
        
        // Remove the /page/X/ part and add ?paged=X instead
        $base_url = preg_replace('/\/page\/\d+\/?/', '', $link);
        $base_url = rtrim($base_url, '/');
        
        // Parse existing query string
        $query_params = array();
        if (!empty($query_string)) {
            parse_str(ltrim($query_string, '?'), $query_params);
        }
        
        // Add paged parameter
        $query_params['paged'] = $page_num;
        
        // Rebuild URL
        $link = $base_url . '?' . http_build_query($query_params);
    }
    
    return $link;
}

/**
 * Redirect problematic pagination URLs to correct format
 */
function tapgrein_redirect_pagination_urls() {
    if (isset($_SERVER['REQUEST_URI'])) {
        $request_uri = $_SERVER['REQUEST_URI'];
        
        // Check if URL contains /page/X/ format
        if (preg_match('/\/page\/(\d+)\/?/', $request_uri, $matches)) {
            $page_num = $matches[1];
            
            // Get current URL without the /page/X/ part
            $clean_url = preg_replace('/\/page\/\d+\/?/', '', $request_uri);
            
            // Parse existing query string
            $url_parts = parse_url($clean_url);
            $query_params = array();
            
            if (isset($url_parts['query'])) {
                parse_str($url_parts['query'], $query_params);
            }
            
            // Add paged parameter
            $query_params['paged'] = $page_num;
            
            // Build correct URL
            $base_url = $url_parts['path'];
            $correct_url = home_url($base_url . '?' . http_build_query($query_params));
            
            // Redirect with 301 status
            wp_redirect($correct_url, 301);
            exit;
        }
    }
}

/**
 * Fix main query to properly handle paged parameter
 */
function tapgrein_fix_main_query_paged($query) {
    // Only modify main query on frontend
    if (is_admin() || !$query->is_main_query()) {
        return;
    }
    
    // Check for paged parameter in URL
    $paged = 0;
    
    // First check $_GET
    if (isset($_GET['paged']) && !empty($_GET['paged'])) {
        $paged = intval($_GET['paged']);
    }
    
    // Then check query var
    if (!$paged && get_query_var('paged')) {
        $paged = intval(get_query_var('paged'));
    }
    
    // Set the paged parameter for the query
    if ($paged > 0) {
        $query->set('paged', $paged);
    }
}

/**
 * Fix canonical redirect that might interfere with pagination
 */
function tapgrein_disable_canonical_redirect_for_pagination() {
    // Check if we have paged parameter
    if (get_query_var('paged') || (isset($_GET['paged']) && !empty($_GET['paged']))) {
        remove_action('template_redirect', 'redirect_canonical');
    }
}
add_action('template_redirect', 'tapgrein_disable_canonical_redirect_for_pagination', 1);

/**
 * Ensure WordPress recognizes custom pagination parameters
 */
function tapgrein_add_pagination_rewrite_rules() {
    // Add rewrite rule for pages with paged parameter
    add_rewrite_rule(
        '(.+?)/page/([0-9]{1,})/?$',
        'index.php?pagename=$matches[1]&paged=$matches[2]',
        'top'
    );
}
add_action('init', 'tapgrein_add_pagination_rewrite_rules');

/**
 * Add custom query vars for pagination
 */
function tapgrein_add_pagination_query_vars($vars) {
    $vars[] = 'paged';
    return $vars;
}
add_filter('query_vars', 'tapgrein_add_pagination_query_vars');

/**
 * Debug function
 * Uncomment to debug pagination issues
 */
/*
function tapgrein_debug_pagination() {
    if (isset($_GET['debug_pagination'])) {
        echo '<div class="tapgoods-debug-info">';
        echo '<strong>Pagination Debug Info:</strong><br>';
        echo 'get_query_var("paged"): ' . get_query_var('paged') . '<br>';
        echo '$_GET["paged"]: ' . (isset($_GET['paged']) ? $_GET['paged'] : 'not set') . '<br>';
        echo 'Current URL: ' . $_SERVER['REQUEST_URI'] . '<br>';
        echo 'is_paged(): ' . (is_paged() ? 'true' : 'false') . '<br>';
        echo '</div>';
    }
}
add_action('wp_head', 'tapgrein_debug_pagination');
*/
